'use client';

import React, { createContext, useContext, ReactNode } from 'react';
import { useBuilderState } from '../hooks/useBuilderState';

type BuilderContextType = ReturnType<typeof useBuilderState>;

const BuilderContext = createContext<BuilderContextType | undefined>(undefined);

export function BuilderProvider({ children }: { children: ReactNode }) {
  const builderState = useBuilderState();

  return (
    <BuilderContext.Provider value={builderState}>
      {children}
    </BuilderContext.Provider>
  );
}

export function useBuilder() {
  const context = useContext(BuilderContext);
  if (context === undefined) {
    throw new Error('useBuilder must be used within a BuilderProvider');
  }
  return context;
}
