// -- File: PageBuilder.tsx --

"use client";

import React, {
  useRef,
  useState,
  useEffect,
  useCallback,
} from 'react';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
  DragStartEvent,
  DragOverEvent,
} from '@dnd-kit/core';
import { arrayMove, sortableKeyboardCoordinates, verticalListSortingStrategy, SortableContext } from '@dnd-kit/sortable';
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from '@/components/ui/resizable';
import { ViewportSizeControls } from '@/app/builder/components/parts/ViewportSizeControls';
import { UndoRedoControls } from '@/app/builder/components/parts/UndoRedoControls';
import { NarrowSidebarButtons } from '@/app/builder/components/parts/NarrowSidebarButtons';
import { SortableLayersPanel } from '@/app/builder/components/parts/SortableLayersPanel';
import { SectionSettingsPanel } from '@/app/builder/components/parts/SectionSettingsPanel';
import { GlobalSettingsPanel } from '@/app/builder/components/parts/GlobalSettingsPanel';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Section, ViewportSize } from '@/app/builder/components/parts/types';
import { ActiveSidebar } from '@/app/builder/components/parts/NarrowSidebarButtons';

export default function PageBuilder() {
  const contentRef = useRef<HTMLIFrameElement>(null);

  // -- States --
  const [viewportSize, setViewportSize] = useState<ViewportSize>('desktop');
  const [isLeftSidebarOpen, setIsLeftSidebarOpen] = useState(true);
  const [screenWidth, setScreenWidth] = useState<number>(window.innerWidth);
  const [sections, setSections] = useState<Section[]>([]);
  const [selectedSectionId, setSelectedSectionId] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [activeNarrowSidebar, setActiveNarrowSidebar] = useState<ActiveSidebar | null>('layers');

  // State for managing global settings panel
  const [isGlobalSettingsPanelOpen, setIsGlobalSettingsPanelOpen] = useState(false);

  // Undo/Redo History
  const [history, setHistory] = useState<Section[][]>([[]]);
  const [currentHistoryIndex, setCurrentHistoryIndex] = useState(0);

  // Sensors for drag & drop
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // For restricting drag axis if needed
  const restrictAxis = (args: any) => {
    const { transform } = args;
    return {
      ...transform,
      x: 0
    };
  };

  // Handler for opening global settings
  const handleOpenGlobalSettings = useCallback(() => {
    setIsGlobalSettingsPanelOpen(true);
  }, []);

  // Handler for closing global settings
  const handleCloseGlobalSettings = useCallback(() => {
    setIsGlobalSettingsPanelOpen(false);
  }, []);

  // ----------------- Undo/Redo Logic -----------------
  useEffect(() => {
    if (currentHistoryIndex === history.length - 1) {
      setHistory((prev) => [...prev, sections]);
      setCurrentHistoryIndex((prev) => prev + 1);
    }
  }, [sections]);

  const handleUndo = () => {
    if (currentHistoryIndex > 0) {
      const newIndex = currentHistoryIndex - 1;
      setSections(history[newIndex]);
      setCurrentHistoryIndex(newIndex);
      window.parent.postMessage(
        {
          type: 'SECTIONS_UPDATED',
          sections: history[newIndex],
        },
        '*'
      );
    }
  };

  const handleRedo = () => {
    if (currentHistoryIndex < history.length - 1) {
      const newIndex = currentHistoryIndex + 1;
      setSections(history[newIndex]);
      setCurrentHistoryIndex(newIndex);
      window.parent.postMessage(
        {
          type: 'SECTIONS_UPDATED',
          sections: history[newIndex],
        },
        '*'
      );
    }
  };

  // ----------------- Screen Resize -----------------
  useEffect(() => {
    const handleResize = () => setScreenWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // ----------------- Viewport Size Change -----------------
  const handleViewportChange = useCallback(
    (size: ViewportSize) => {
      setViewportSize(size);
      switch (size) {
        case 'desktop':
          setIsLeftSidebarOpen(true);
          setActiveNarrowSidebar('layers');
          break;
        case 'fullscreen':
          setIsLeftSidebarOpen(false);
          setActiveNarrowSidebar(null);
          break;
        case 'mobile':
        case 'tablet':
          setIsLeftSidebarOpen(true);
          setActiveNarrowSidebar('layers');
          break;
      }
      contentRef.current?.contentWindow?.postMessage(
        {
          type: 'VIEWPORT_CHANGE',
          viewport: size,
        },
        '*'
      );
    },
    [contentRef]
  );

  // ----------------- Toggle Narrow Sidebar -----------------
  const toggleNarrowSidebar = useCallback((type: ActiveSidebar) => {
    if (type === null) return;
    setActiveNarrowSidebar(type);
  }, []);

  // ----------------- DnD Handlers -----------------
  const handleDragStart = (event: DragStartEvent) => {
    setIsDragging(true);
    contentRef.current?.contentWindow?.postMessage(
      {
        type: 'DRAG_START',
        sectionId: event.active.id,
      },
      '*'
    );
  };

  const handleDragOver = (event: DragOverEvent) => {
    const { active, over } = event;
    if (active.id !== over?.id) {
      contentRef.current?.contentWindow?.postMessage(
        {
          type: 'DRAG_OVER',
          activeSectionId: active.id,
          overSectionId: over?.id,
        },
        '*'
      );
    }
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setIsDragging(false);

    if (active.id !== over?.id) {
      setSections((prevSections) => {
        const oldIndex = prevSections.findIndex((sec) => sec.id === active.id);
        const newIndex = prevSections.findIndex((sec) => sec.id === over?.id);
        const newArr = arrayMove(prevSections, oldIndex, newIndex);
        contentRef.current?.contentWindow?.postMessage(
          {
            type: 'REORDER_SECTIONS',
            sections: newArr,
          },
          '*'
        );
        return newArr;
      });
    }
  };

  // ----------------- Hover & Select Handlers -----------------
  const handleSectionHover = useCallback((id: string | null) => {
    // Nothing special if we only highlight
  }, []);

  const handleSelectSection = useCallback(
    (id: string) => {
      setSelectedSectionId(id);
      if (screenWidth <= 1612) {
        setActiveNarrowSidebar('settings');
      }
      contentRef.current?.contentWindow?.postMessage(
        {
          type: 'SCROLL_TO_SECTION',
          sectionId: id,
        },
        '*'
      );
    },
    [screenWidth, contentRef]
  );

  // ----------------- Update Section -----------------
  const handleUpdateSection = useCallback(
    (sectionId: string, updates: Partial<Section>) => {
      console.group('🔍 UpdateSection Debug');
      console.log('Input sectionId:', sectionId);
      console.log('Input updates:', updates);

      const currentSection = sections.find((s) => s.id === sectionId);
      if (!currentSection) {
        console.error('Section not found');
        console.groupEnd();
        return;
      }

      console.log('Current section before update:', currentSection);

      const newSection: Section = {
        ...currentSection,
        // If you store “settings” or “blocks” differently, handle merges here
        ...(updates as any),
      };

      console.log('New section after update:', newSection);

      const idx = sections.findIndex((s) => s.id === sectionId);
      if (idx !== -1) {
        const updatedSections = [...sections];
        updatedSections[idx] = newSection;
        console.log('Sections after update:', updatedSections);
        setSections(updatedSections);
        contentRef.current?.contentWindow?.postMessage(
          {
            type: 'UPDATE_SECTION',
            sectionId: sectionId,
            updates,
          },
          '*'
        );
        window.parent.postMessage(
          {
            type: 'SECTIONS_UPDATED',
            sections: updatedSections,
          },
          '*'
        );
      }
      console.groupEnd();
    },
    [sections, contentRef]
  );

  // ----------------- Iframe Message Listener -----------------
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      // Ignore messages not from the iframe
      if (event.source !== contentRef.current?.contentWindow) return;

      try {
        switch (event.data.type) {
          case 'SECTION_SELECTED': {
            if (event.data.sectionId) {
              const foundSection = sections.find((sec) => sec.id === event.data.sectionId);
              if (foundSection) {
                setSelectedSectionId(foundSection.id);
                if (event.data.action === 'OPEN_SETTINGS' && screenWidth <= 1612) {
                  setActiveNarrowSidebar('settings');
                }
              }
            }
            break;
          }

          case 'UPDATE_SECTION': {
            handleUpdateSection(event.data.sectionId, event.data.updates);
            break;
          }

          case 'SHOW_BLOCK_SETTINGS': {
            if (screenWidth <= 1612) {
              // For narrow screens, switch to settings sidebar
              toggleNarrowSidebar('settings');
            }

            // Set the selected section to a temporary block settings section
            const blockSettingsSection = {
              id: 'block-settings',
              type: event.data.block.type,
              settings: event.data.block
            };

            // Update state to show block settings
            setSelectedSectionId('block-settings');
            setSections(prevSections => {
              // Replace or add block settings section
              const existingIndex = prevSections.findIndex(s => s.id === 'block-settings');
              if (existingIndex !== -1) {
                const updatedSections = [...prevSections];
                updatedSections[existingIndex] = blockSettingsSection;
                return updatedSections;
              }
              return [...prevSections, blockSettingsSection];
            });
            break;
          }

          case 'SECTIONS_UPDATED': {
            if (Array.isArray(event.data.sections)) {
              setSections(event.data.sections);
            }
            break;
          }

          case 'SELECT_SECTION': {
            if (event.data.sectionId) {
              const s = sections.find((sec) => sec.id === event.data.sectionId);
              if (s) setSelectedSectionId(s.id);
            }
            break;
          }

          case 'ADD_SECTION': {
            const { section, index } = event.data;
            setSections((prevSections) => {
              const newSections = [...prevSections];
              if (index !== undefined && index !== null) {
                newSections.splice(index, 0, section);
              } else {
                newSections.push(section);
              }
              return newSections;
            });
            setSelectedSectionId(section.id);
            break;
          }

          default:
            break;
        }
      } catch (error) {
        console.error('Error handling message:', error);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [
    sections, 
    screenWidth, 
    toggleNarrowSidebar, 
    handleUpdateSection, 
    contentRef
  ]);

  // ----------------- RENDER -----------------
  return (
    <TooltipProvider>
      <div className="h-screen flex flex-col">
        {/* TOP CONTROL BAR */}
        <div className="flex justify-between items-center p-2 border-b">
          <div className="flex items-center space-x-2">
            {/* Other left-side controls if needed */}
          </div>

          <div className="flex items-center space-x-2">
            <ViewportSizeControls currentSize={viewportSize} onChange={handleViewportChange} />
            <UndoRedoControls onUndo={handleUndo} onRedo={handleRedo} />
            <button onClick={handleOpenGlobalSettings}>Open Global Settings</button>
          </div>
        </div>

        {/* MAIN CONTENT */}
        <div className="flex flex-grow overflow-hidden">
          {screenWidth <= 1612 && viewportSize !== 'fullscreen' && (
            <NarrowSidebarButtons 
              active={activeNarrowSidebar} 
              onToggle={toggleNarrowSidebar} 
              onOpenGlobalSettings={handleOpenGlobalSettings}
            />
          )}
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragStart={handleDragStart}
            onDragOver={handleDragOver}
            onDragEnd={handleDragEnd}
            modifiers={[restrictAxis]}
          >
            <SortableContext items={sections.map((s) => s.id)} strategy={verticalListSortingStrategy}>
              <ResizablePanelGroup direction="horizontal" className="flex-grow">
                {/* LEFT SIDEBAR */}
                <ResizablePanel
                  defaultSize={20}
                  minSize={10}
                  maxSize={30}
                  className={`bg-white shadow-md ${!isLeftSidebarOpen ? 'hidden' : ''}`}
                >
                  <div className="h-full flex flex-col">
                    <h2 className="text-md font-semibold border-b p-3">Page Name</h2>
                    {(screenWidth > 1612 || activeNarrowSidebar === 'layers') && (
                      <>
                      <div className='p-3 border-b'>
                        <h2 className="text-sm font-semibold">Header</h2>
                      </div>
                      <div className='border-b p-3'>
                        <h2 className='text-sm font-semibold'>Template</h2>
                        <SortableLayersPanel
                          sections={sections}
                          selectedSectionId={selectedSectionId}
                          onSelectSection={handleSelectSection}
                          onHoverSection={handleSectionHover}
                          setSections={setSections}
                          contentRef={contentRef}
                        />
                      </div>
                      <div className='p-3 border-b'>
                        <h2 className="text-sm font-semibold">Footer</h2>
                      </div>
                        </>
                    )}

                    {screenWidth <= 1612 && activeNarrowSidebar === 'settings' && (
                      <>
                        <div className="p-4 border-b">
                          <h2 className="text-xl font-bold">Section Settings</h2>
                        </div>
                        <SectionSettingsPanel
                          selectedSectionId={selectedSectionId}
                          sections={sections}
                          contentRef={contentRef}
                          onToggleLayers={() => toggleNarrowSidebar('layers')}
                        />
                      </>
                    )}
                    {screenWidth <= 1612 && activeNarrowSidebar === 'global-settings' && (
                      <div className="flex-grow overflow-y-auto">
                        <div className="p-4 border-b">
                          <h2 className="text-xl font-bold">Global Settings</h2>
                        </div>
                        <GlobalSettingsPanel 
                          contentRef={contentRef} 
                          onClose={() => setActiveNarrowSidebar(null)} 
                        />
                      </div>
                    )}
                  </div>
                </ResizablePanel>

                {isLeftSidebarOpen && <ResizableHandle withHandle />}

                {/* CONTENT PANEL (IFRAME) */}
                <ResizablePanel
                  defaultSize={screenWidth > 1612 ? 70 : 85}
                  minSize={50}
                  className="flex justify-center items-center bg-gray-100 relative"
                >
                  <div className="absolute inset-0 flex justify-center items-center p-2">
                    <div
                      className="w-full h-full flex justify-center items-center transition-all duration-300 ease-in-out"
                      style={{
                        transform: isDragging ? 'scale(0.9)' : 'scale(1)',
                        transformOrigin: 'center',
                        width:
                          viewportSize === 'mobile'
                            ? '375px'
                            : viewportSize === 'tablet'
                            ? '768px'
                            : viewportSize === 'fullscreen'
                            ? '100%'
                            : '100%',
                        height:
                          viewportSize === 'mobile'
                            ? '667px'
                            : viewportSize === 'tablet'
                            ? '1024px'
                            : viewportSize === 'fullscreen'
                            ? '100%'
                            : '100%',
                        maxWidth: '100%',
                        maxHeight: '100%',
                      }}
                    >
                      <iframe
                        ref={contentRef}
                        src="/builder/content"
                        className="w-full h-full"
                        style={{ width: '100%', height: '100%' }}
                      />
                    </div>
                  </div>
                </ResizablePanel>

                {/* RIGHT SIDEBAR (only if wide) */}
                {screenWidth > 1612 && (
                  <>
                    <ResizableHandle withHandle />
                    <ResizablePanel
                      defaultSize={15}
                      minSize={10}
                      maxSize={30}
                      className="bg-white shadow-md"
                    >
                      <div className="p-4 h-full overflow-y-auto">
                        <h2 className="text-xl font-bold mb-4">Section Settings</h2>
                        <SectionSettingsPanel
                          selectedSectionId={selectedSectionId}
                          sections={sections}
                          contentRef={contentRef}
                          onToggleLayers={() => toggleNarrowSidebar('layers')}
                        />
                      </div>
                    </ResizablePanel>
                  </>
                )}
              </ResizablePanelGroup>
            </SortableContext>
          </DndContext>
        </div>
      </div>
    </TooltipProvider>
  );
}
