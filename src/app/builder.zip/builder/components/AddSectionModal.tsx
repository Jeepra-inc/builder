'use client';

import * as React from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";
import { 
  Command, 
  CommandEmpty, 
  CommandInput, 
  CommandList 
} from "@/components/ui/command";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus } from 'lucide-react';
import { Button } from "@/components/ui/button";
import NextImage from 'next/image';
import { SectionType } from '@/app/builder/builder';
import { sectionRegistry } from '@/app/builder/elements/sections/section-registry';
import '@/app/builder/elements/sections/section-auto-register';

export interface AddSectionModalProps {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  onAddSection: (sectionType: SectionType) => void;
}

export const AddSectionModal: React.FC<AddSectionModalProps> = ({ 
  open: externalOpen, 
  onOpenChange: externalOnOpenChange, 
  onAddSection 
}) => {
  const [internalOpen, setInternalOpen] = React.useState(false);
  const [searchTerm, setSearchTerm] = React.useState('');
  const [activeTab, setActiveTab] = React.useState(sectionRegistry.getGroups()[0]);

  const open = externalOpen ?? internalOpen;
  const onOpenChange = externalOnOpenChange ?? setInternalOpen;

  const handleAddSection = (sectionType: SectionType) => {
    onAddSection(sectionType);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon">
          <Plus className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl h-[80vh] flex p-0 overflow-hidden">
        <VisuallyHidden>
          <DialogTitle>Add New Section</DialogTitle>
        </VisuallyHidden>
        <Tabs 
          value={activeTab} 
          onValueChange={setActiveTab} 
          className="w-full flex"
        >
          <div className="w-1/4 border-r bg-accent">
            <TabsList className="grid w-full grid-cols-1 gap-0 bg-accent">
              {sectionRegistry.getGroups().map(group => (
                <TabsTrigger 
                  key={group} 
                  value={group} 
                  className="py-2 px-4 justify-start text-left hover:bg-accent/50 data-[state=active]:bg-accent/80 group"
                  onMouseEnter={() => setActiveTab(group)}
                >
                  {group.charAt(0).toUpperCase() + group.slice(1)}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>
          <div className="w-3/4 py-2">
            <Command>
              <CommandInput 
                placeholder="Search sections..." 
                value={searchTerm}
                onValueChange={setSearchTerm}
              />
              <CommandList>
                <CommandEmpty>No sections found.</CommandEmpty>
                {sectionRegistry.getGroups().map(group => (
                  <TabsContent key={group} value={group}>
                    <div className="grid grid-cols-2 gap-4 p-4">
                      {sectionRegistry.getSectionsByGroup(group)
                        .filter(section => 
                          !searchTerm || 
                          section.name.toLowerCase().includes(searchTerm.toLowerCase())
                        )
                        .map(section => (
                          <div 
                            key={section.type} 
                            className="cursor-pointer hover:bg-accent/10 rounded-lg p-2 text-center"
                            onClick={() => handleAddSection(section.type)}
                          >
                            <div className="aspect-video relative mb-2">
                              <NextImage 
                                src={section.placeholderImage} 
                                alt={`${section.name} placeholder`}
                                fill
                                className="object-cover rounded-md"
                              />
                            </div>
                            <p className="text-sm font-medium">{section.name}</p>
                          </div>
                        ))
                      }
                      {sectionRegistry.getSectionsByGroup(group)
                        .filter(section => section.type === 'banner')
                        .map(section => (
                          <div 
                            key={section.type} 
                            className="cursor-pointer hover:bg-accent/10 rounded-lg p-2 text-center"
                            onClick={() => handleAddSection(section.type)}
                          >
                            <div className="aspect-video relative mb-2">
                              <NextImage 
                                src={section.placeholderImage} 
                                alt={`${section.name} placeholder`}
                                fill
                                className="object-cover rounded-md"
                              />
                            </div>
                            <p className="text-sm font-medium">{section.name}</p>
                          </div>
                        ))}
                    </div>
                  </TabsContent>
                ))}
              </CommandList>
            </Command>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};
