import React, { 
  ReactNode, 
  isValidElement 
} from 'react';
import { BlockRegistry } from '../../elements/blocks/registry';
import { BlockSettings } from '../../elements/blocks/blocks';
import AddBlockPopover from '@/components/ui/add-block-popover';

// Define available block types
const DEFAULT_BLOCK_TYPES: Array<keyof typeof BlockRegistry> = [
  'image', 
  'heading', 
  'paragraph'
];

export interface BlockAdditionWrapperProps {
  index: number;
  isHovered: boolean;
  activePopoverIndex: number | null;
  setActivePopoverIndex: (index: number | null) => void;
  setHoveredBlockId: (id: string | null) => void;
  children: ReactNode;
  availableBlockTypes?: Array<keyof typeof BlockRegistry>;
  addBlock?: (
    blockType: keyof typeof BlockRegistry, 
    index?: number, 
    defaultValues?: Partial<BlockSettings>
  ) => void;
  hasReachedAllBlockLimits?: boolean;
  defaultBlockValues?: Record<keyof typeof BlockRegistry, Partial<BlockSettings>>;
  setSections?: React.Dispatch<React.SetStateAction<any[]>>;
  sections?: any[];
}

export const BlockAdditionWrapper: React.FC<BlockAdditionWrapperProps> = ({
  index,
  isHovered,
  activePopoverIndex,
  setActivePopoverIndex,
  setHoveredBlockId,
  children,
  availableBlockTypes = DEFAULT_BLOCK_TYPES,
  addBlock = () => console.log('Add block not implemented'),
  hasReachedAllBlockLimits = false,
  defaultBlockValues = {},
  setSections,
  sections
}) => {
  const handleMouseEnter = (newIndex: number) => {
    setActivePopoverIndex(newIndex);
  };

  const handleMouseLeave = () => {
    setActivePopoverIndex(null);
    setHoveredBlockId(null);
  };

  const handleOpenChange = (open: boolean, newIndex: number) => {
    setActivePopoverIndex(open ? newIndex : null);
    if (!open) setHoveredBlockId(null);
  };

  const handleAddBlock = (blockType: keyof typeof BlockRegistry, addIndex: number) => {
    // Merge default values for the specific block type
    const blockDefaultValues = defaultBlockValues[blockType] || {};
    
    // Create a new block with merged default values
    addBlock(blockType, addIndex, blockDefaultValues);
  };

  return (
    <div 
      className="relative group"
      onMouseEnter={() => setHoveredBlockId(
        isValidElement(children) ? children.props.block?.id : null
      )}
      onMouseLeave={() => {
        if (activePopoverIndex !== index * 2 && activePopoverIndex !== index * 2 + 1) {
          setHoveredBlockId(null);
        }
      }}
    >
      {/* Top Add Block */}
      {(isHovered || activePopoverIndex === index * 2) && !hasReachedAllBlockLimits && (
        <div 
          className="absolute -top-2 left-1/2 -translate-x-1/2 opacity-100 transition-opacity z-20 group/top"
          onMouseEnter={() => handleMouseEnter(index * 2)}
          onMouseLeave={handleMouseLeave}
        >
          <div className="relative">
            <div className="absolute -inset-x-0 -top-0.5 bg-blue-600 opacity-0 group-hover/top:animate-grow-line h-0.5 transition-opacity duration-300"></div>
            <AddBlockPopover 
              availableBlockTypes={availableBlockTypes}
              onAddBlock={(blockType) => handleAddBlock(blockType, index)}
              open={activePopoverIndex === index * 2}
              onOpenChange={(open) => handleOpenChange(open, index * 2)}
              index={index}
              setSections={setSections}
              sections={sections}
            />
          </div>
        </div>
      )}

      {children}

      {/* Bottom Add Block */}
      {(isHovered || activePopoverIndex === index * 2 + 1) && !hasReachedAllBlockLimits && (
        <div 
          className="absolute -bottom-2 left-1/2 -translate-x-1/2 opacity-100 transition-opacity z-20 group/bottom"
          onMouseEnter={() => handleMouseEnter(index * 2 + 1)}
          onMouseLeave={handleMouseLeave}
        >
          <div className="relative">
            <div className="absolute -inset-x-0 -bottom-0.5 bg-blue-600 opacity-0 group-hover/bottom:animate-grow-line h-0.5 transition-opacity duration-300"></div>
            <AddBlockPopover 
              availableBlockTypes={availableBlockTypes}
              onAddBlock={(blockType) => handleAddBlock(blockType, index + 1)}
              open={activePopoverIndex === index * 2 + 1}
              onOpenChange={(open) => handleOpenChange(open, index * 2 + 1)}
              index={index + 1}
              setSections={setSections}
              sections={sections}
            />
          </div>
        </div>
      )}
    </div>
  );
};
