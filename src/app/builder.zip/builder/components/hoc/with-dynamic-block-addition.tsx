import React, { 
  ComponentType, 
  useState, 
  ReactNode, 
  isValidElement 
} from 'react';
import { BlockRegistry, createDefaultBlock } from '../../elements/blocks/registry';
import { BlockSettings } from '../../elements/blocks/types';
import AddBlockPopover from '@/components/ui/add-block-popover';

// Define block type limits (you can make this configurable)
const DEFAULT_BLOCK_TYPE_LIMITS: Record<keyof typeof BlockRegistry, number> = {
  'heading': 2,
  'paragraph': 4,
  'image': 2
};

// Define available block types
const DEFAULT_BLOCK_TYPES: Array<keyof typeof BlockRegistry> = [
  'image', 
  'heading', 
  'paragraph'
];

export interface DynamicBlockAdditionProps {
  blocks: BlockSettings[];
  setBlocks: (blocks: BlockSettings[]) => void;
  blockTypes?: Array<keyof typeof BlockRegistry>;
  blockTypeLimits?: Record<keyof typeof BlockRegistry, number>;
}

export function withDynamicBlockAddition<P extends { blocks?: BlockSettings[], blockTypes?: Array<keyof typeof BlockRegistry>, blockTypeLimits?: Record<keyof typeof BlockRegistry, number> }>(
  WrappedComponent: ComponentType<P & { blocks: BlockSettings[] }>
) {
  return function DynamicBlockAdditionWrapper(props: P) {
    // Use props or default to initial blocks
    const [blocks, setBlocks] = useState<BlockSettings[]>(
      props.blocks || [
        createDefaultBlock('image'),
        createDefaultBlock('heading'),
        createDefaultBlock('paragraph')
      ]
    );

    // Merge default and provided block types/limits
    const blockTypes = props.blockTypes || DEFAULT_BLOCK_TYPES;
    const blockTypeLimits = {
      ...DEFAULT_BLOCK_TYPE_LIMITS,
      ...props.blockTypeLimits
    };

    // Function to count blocks of a specific type
    const countBlocksByType = (blockType: keyof typeof BlockRegistry): number => {
      return blocks.filter(block => block.type === blockType).length;
    };

    // Check if all block type limits have been reached
    const hasReachedAllBlockLimits = blockTypes.every(
      blockType => countBlocksByType(blockType) >= blockTypeLimits[blockType]
    );

    // Modify block types to only show those that haven't reached their limit
    const availableBlockTypes = blockTypes.filter(
      blockType => countBlocksByType(blockType) < blockTypeLimits[blockType]
    );

    const addBlock = (blockType: keyof typeof BlockRegistry, index?: number) => {
      // Check if the block type limit has been reached
      if (countBlocksByType(blockType) >= blockTypeLimits[blockType]) {
        return; // Do not add block if limit is reached
      }

      const newBlock = createDefaultBlock(blockType);
      const newBlocks = [...blocks];
      
      if (index !== undefined) {
        newBlocks.splice(index, 0, newBlock);
      } else {
        newBlocks.push(newBlock);
      }

      setBlocks(newBlocks);
    };


    // Render the wrapped component with additional props
    return (
      <WrappedComponent 
        {...props as P} 
        blocks={blocks}
        renderWithBlockAddition={(children: ReactNode) => (
          <div className="relative">
            {React.Children.map(children, (child, index) => {
              if (!isValidElement(child)) return child;

              return (
                <div className="relative group">
                  {/* Top Add Block */}
                  {!hasReachedAllBlockLimits && (
                    <div className="absolute -top-2 left-1/2 -translate-x-1/2 opacity-100 transition-opacity z-20">
                      <AddBlockPopover 
                        availableBlockTypes={availableBlockTypes}
                        onAddBlock={(blockType, idx) => addBlock(blockType, index)}
                        index={index}
                      />
                    </div>
                  )}

                  {child}

                  {/* Bottom Add Block */}
                  {!hasReachedAllBlockLimits && (
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 opacity-100 transition-opacity z-20">
                      <AddBlockPopover 
                        availableBlockTypes={availableBlockTypes}
                        onAddBlock={(blockType, idx) => addBlock(blockType, index + 1)}
                        index={index + 1}
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      />
    );
  };
}
