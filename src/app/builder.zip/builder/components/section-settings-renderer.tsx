'use client';

import React, { useState, useEffect } from 'react';
import { Section, SettingField, SectionType } from '@/app/builder/builder';
import { sections } from '@/app/builder/elements/sections';
import { BlockRegistry, BlockRegistryItem } from '@/app/builder/elements/blocks/registry';

// Import your input components
const InputComponents = {
  text: ({ 
    value, 
    onChange, 
    field,
    ...props 
  }: { 
    value: string | undefined | null, 
    onChange: (val: string) => void,
    field?: any
  }) => {
    const stringValue = value ?? '';
    return (
      <input 
        type="text" 
        value={stringValue}
        onChange={(e) => onChange(e.target.value)}
        className="block w-full p-2 border border-gray-300 rounded-lg"
        {...props}
      />
    );
  },
  textarea: ({ 
    value, 
    onChange, 
    field,
    ...props 
  }: { 
    value: string | undefined | null, 
    onChange: (val: string) => void,
    field?: any
  }) => {
    const stringValue = value ?? '';
    return (
      <textarea 
        value={stringValue}
        onChange={(e) => onChange(e.target.value)}
        className="block w-full p-2 border border-gray-300 rounded-lg"
        {...props}
      />
    );
  },
  number: ({ 
    value, 
    onChange, 
    field,
    ...props 
  }: { 
    value: number | string | undefined | null, 
    onChange: (val: number) => void,
    field?: any
  }) => {
    const numberValue = value ?? '';
    return (
      <input 
        type="number" 
        value={numberValue}
        onChange={(e) => onChange(Number(e.target.value))}
        className="block w-full p-2 border border-gray-300 rounded-lg"
        {...props}
      />
    );
  },
  select: ({ 
    value, 
    onChange, 
    options,
    field,
    ...props 
  }: { 
    value: string | undefined | null, 
    onChange: (val: string) => void,
    options?: Array<{value: string, label: string}>,
    field?: any
  }) => {
    const stringValue = value ?? '';
    return (
      <select 
        value={stringValue}
        onChange={(e) => onChange(e.target.value)}
        className="block w-full p-2 border border-gray-300 rounded-lg"
        {...props}
      >
        {options?.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    );
  },
  color: ({ 
    value, 
    onChange, 
    field,
    ...props 
  }: { 
    value: string | undefined | null, 
    onChange: (val: string) => void,
    field?: any
  }) => {
    const stringValue = value ?? '';
    return (
      <input 
        type="color" 
        value={stringValue}
        onChange={(e) => onChange(e.target.value)}
        className="block w-full p-2 border border-gray-300 rounded-lg"
        {...props}
      />
    );
  }
};

const getInputValue = (section: Section, field: any) => {
  const value = section.settings?.[field.id] ?? field.default;
  
  // Handle type conversion
  switch (field.type) {
    case 'number':
      return value !== undefined ? Number(value) : '';
    case 'text':
    case 'textarea':
      return value !== undefined ? String(value) : '';
    default:
      return value;
  }
};

export interface SectionSettingsRendererProps {
  section: Section;
  onUpdateSection: (updates: Record<string, any>) => void;
}

export function SectionSettingsRenderer({ 
  section, 
  onUpdateSection
}: SectionSettingsRendererProps) {
  const [localSettings, setLocalSettings] = useState<Record<string, any>>(() => {
    // Flatten nested settings
    return {
      ...section.settings?.settings,
      ...section.settings
    };
  });

  useEffect(() => {
    // Update local settings when section changes
    setLocalSettings({
      ...section.settings?.settings,
      ...section.settings
    });
  }, [section.id, section.settings]);

  const handleSettingChange = (fieldId: string, value: any) => {
    console.log('Handling setting change:', { fieldId, value });
    
    const updatedSettings = {
      ...localSettings,
      [fieldId]: value
    };

    // Prepare update payload
    const updatePayload = {
      sectionId: section.id,
      updates: {
        settings: updatedSettings
      }
    };

    // Send update to parent window
    window.parent.postMessage({
      type: 'UPDATE_SECTION',
      ...updatePayload
    }, '*');

    // Optimistically update local state
    setLocalSettings(updatedSettings);
    onUpdateSection?.({
      settings: updatedSettings
    });
  };

  // Get the section schema from the default theme
  const getCorrectSectionConfig = () => {
    // Try to get section config from sections registry
    const mappedType = section.type;
    
    if (mappedType && sections.sections[mappedType]) {
      return sections.sections[mappedType];
    }

    // Try block registry for block settings
    const blockConfig = BlockRegistry[section.type as keyof typeof BlockRegistry];
    
    if (blockConfig?.component?.Settings) {
      // Instead of accessing .fields, return a default empty settings array
      return {
        settings: [] // Or implement a way to extract settings from the Settings component
      };
    }

    // Fallback to a default or log error
    console.error(`No configuration found for section/block type: ${section.type}`);
    return null;
  };

  const correctSectionConfig = getCorrectSectionConfig();

  if (!correctSectionConfig) {
    console.error(`Completely unable to find configuration for section type: ${section.type}`);
    return <div>No settings schema available for this section type: {section.type}</div>;
  }

  // Prioritize settings, fallback to schema
  const schemaFields = correctSectionConfig.settings || [];

  return (
    <div className="space-y-4">
      {schemaFields.map((field: SettingField) => {
        const currentValue = localSettings?.[field.id];
        
        switch (field.type) {
          case 'text':
            return (
              <div key={field.id}>
                <label className="block text-sm font-medium text-gray-700 mb-1">{field.label}</label>
                <InputComponents.text
                  value={currentValue || field.default || ''}
                  onChange={(val) => handleSettingChange(field.id, val)}
                  field={field}
                />
              </div>
            );
          case 'textarea':
            return (
              <div key={field.id}>
                <label className="block text-sm font-medium text-gray-700 mb-1">{field.label}</label>
                <InputComponents.textarea
                  value={currentValue || field.default || ''}
                  onChange={(val) => handleSettingChange(field.id, val)}
                  field={field}
                />
              </div>
            );
          case 'color':
            return (
              <div key={field.id}>
                <label className="block text-sm font-medium text-gray-700 mb-1">{field.label}</label>
                <InputComponents.color
                  value={currentValue || field.default || ''}
                  onChange={(val) => handleSettingChange(field.id, val)}
                  field={field}
                />
              </div>
            );
          case 'select':
            return (
              <div key={field.id}>
                <label className="block text-sm font-medium text-gray-700 mb-1">{field.label}</label>
                <InputComponents.select
                  value={currentValue || field.default || ''}
                  onChange={(val) => handleSettingChange(field.id, val)}
                  field={field}
                  options={field.options}
                />
              </div>
            );
          case 'number':
            return (
              <div key={field.id}>
                <label className="block text-sm font-medium text-gray-700 mb-1">{field.label}</label>
                <InputComponents.number
                  value={currentValue || field.default || ''}
                  onChange={(val) => handleSettingChange(field.id, val)}
                  field={field}
                />
              </div>
            );
          // Add other input types as needed
          default:
            console.warn(`Unsupported field type: ${field.type}`);
            return null;
        }
      })}
    </div>
  );
}
