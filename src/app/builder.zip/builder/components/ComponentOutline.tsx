import React, { useState, useEffect, useCallback } from 'react';

interface ComponentOutlineProps {
  enabled?: boolean;
}

/**
 * A simple React component that highlights hovered and selected
 * [data-section-type] elements on the page, with special handling
 * for elements near the top of the viewport.
 */
export const ComponentOutline: React.FC<ComponentOutlineProps> = ({ enabled = true }) => {
  const [hoveredElement, setHoveredElement] = useState<HTMLElement | null>(null);
  const [selectedElement, setSelectedElement] = useState<HTMLElement | null>(null);

  const [hoveredRect, setHoveredRect] = useState<DOMRect | null>(null);
  const [selectedRect, setSelectedRect] = useState<DOMRect | null>(null);

  const [hoveredSectionType, setHoveredSectionType] = useState<string>('');
  const [selectedSectionType, setSelectedSectionType] = useState<string>('');

  /**
   * Return true if the element's top is at or above 10px from the top of the viewport.
   * Adjust the threshold to your preference.
   */
  const isTopComponent = useCallback((rect: DOMRect) => {
    return rect.top <= 10;
  }, []);

  const getRect = (el: HTMLElement) => el.getBoundingClientRect();

  // ----- Update hovered outline -----
  const updateHoveredOutline = useCallback(
    (element: HTMLElement | null) => {
      if (!element) {
        setHoveredElement(null);
        setHoveredRect(null);
        setHoveredSectionType('');
        return;
      }
      setHoveredElement(element);
      setHoveredRect(getRect(element));
      setHoveredSectionType(element.getAttribute('data-section-type') || 'Section');
    },
    []
  );

  // ----- Update selected outline -----
  const updateSelectedOutline = useCallback(
    (element: HTMLElement | null) => {
      if (!element) {
        setSelectedElement(null);
        setSelectedRect(null);
        setSelectedSectionType('');
        return;
      }
      setSelectedElement(element);
      setSelectedRect(getRect(element));
      setSelectedSectionType(element.getAttribute('data-section-type') || 'Section');
    },
    []
  );

  // ----- Scroll / Resize -> Recompute Outline Positions -----
  const handleScrollOrResize = useCallback(() => {
    if (selectedElement) {
      updateSelectedOutline(selectedElement);
    }
    if (hoveredElement) {
      updateHoveredOutline(hoveredElement);
    }
  }, [selectedElement, hoveredElement, updateSelectedOutline, updateHoveredOutline]);

  // ----- Mousemove -> Hover Outline -----
  const handleMouseMove = useCallback(
    (event: MouseEvent) => {
      if (!enabled) return;

      const target = event.target as HTMLElement;
      const sectionElement = target.closest('[data-section-type]') as HTMLElement | null;

      if (sectionElement && sectionElement !== hoveredElement) {
        updateHoveredOutline(sectionElement);
      } else if (!sectionElement) {
        // If mouse is not over any section
        updateHoveredOutline(null);
      }
    },
    [enabled, hoveredElement, updateHoveredOutline]
  );

  // ----- Mouseleave -> Remove Hover Outline -----
  const handleMouseLeave = useCallback(() => {
    // Clear hover only if we truly leave the document
    updateHoveredOutline(null);
  }, [updateHoveredOutline]);

  // ----- Click -> Select or Deselect Outline -----
  const handleClick = useCallback(
    (event: MouseEvent) => {
      if (!enabled) return;

      const target = event.target as HTMLElement;
      const sectionElement = target.closest('[data-section-type]') as HTMLElement | null;

      if (!sectionElement) return; // clicked outside any section

      if (selectedElement === sectionElement) {
        // Deselect if the same element is clicked
        updateSelectedOutline(null);
      } else {
        // Otherwise select the new element immediately
        updateSelectedOutline(sectionElement);
      }
    },
    [enabled, selectedElement, updateSelectedOutline]
  );

  // ----- Add/Remove Event Listeners -----
  useEffect(() => {
    if (!enabled) return;

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('click', handleClick);
    window.addEventListener('scroll', handleScrollOrResize, true);
    window.addEventListener('resize', handleScrollOrResize);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('click', handleClick);
      window.removeEventListener('scroll', handleScrollOrResize, true);
      window.removeEventListener('resize', handleScrollOrResize);
    };
  }, [
    enabled,
    handleMouseMove,
    handleMouseLeave,
    handleClick,
    handleScrollOrResize,
  ]);

  // ----- Build Outline Style (hover vs selected) -----
  const buildOutlineStyle = (rect: DOMRect | null, isSelected: boolean): React.CSSProperties => {
    if (!rect) return { display: 'none' };

    // Use isTopComponent to determine top radius
    const topRounded = isTopComponent(rect) ? '8px 8px 0 0' : '0';

    return {
      position: 'fixed',
      top: rect.top,
      left: rect.left,
      width: rect.width,
      height: rect.height,
      pointerEvents: 'none',
      zIndex: 9999,
      boxSizing: 'border-box',
      border: isSelected ? '3px solid #4A90E2' : '2px solid #4A90E2',
      backgroundColor: isSelected ? 'rgba(74, 144, 226, 0.1)' : 'transparent',
      borderRadius: topRounded,
    };
  };

  const hoveredStyle = buildOutlineStyle(hoveredRect, false);
  const selectedStyle = buildOutlineStyle(selectedRect, true);

  // For the label positioning, we do the same logic for both hovered & selected.
  // If the rect is near the top, place the label inside. Otherwise, place above.
  const hoveredLabelPosition = useCallback(() => {
    if (!hoveredRect) return { top: '-24px', left: '0' };
    return isTopComponent(hoveredRect)
      ? { top: '4px', left: '4px' }
      : { top: '-24px', left: '0' };
  }, [hoveredRect, isTopComponent]);

  const selectedLabelPosition = useCallback(() => {
    if (!selectedRect) return { top: '-24px', left: '0' };
    return isTopComponent(selectedRect)
      ? { top: '4px', left: '4px' }
      : { top: '-24px', left: '0' };
  }, [selectedRect, isTopComponent]);

  if (!enabled) return null;

  return (
    <>
      {/* Hover Outline */}
      {hoveredRect && (
        <div style={hoveredStyle}>
          <div
            style={{
              position: 'absolute',
              backgroundColor: '#4A90E2',
              color: 'white',
              padding: '2px 8px',
              borderRadius: '4px',
              fontSize: '12px',
              fontWeight: 'bold',
              pointerEvents: 'none',
              // Merge in our dynamic top/left for hover
              ...hoveredLabelPosition(),
            }}
          >
            {hoveredSectionType}
          </div>
        </div>
      )}

      {/* Selected Outline */}
      {selectedRect && (
        <div style={selectedStyle}>
          <div
            style={{
              position: 'absolute',
              backgroundColor: '#0070f3',
              color: 'white',
              padding: '2px 8px',
              borderRadius: '4px',
              fontSize: '12px',
              fontWeight: 'bold',
              pointerEvents: 'none',
              // Merge in our dynamic top/left for selected
              ...selectedLabelPosition(),
            }}
          >
            {selectedSectionType} (Selected)
          </div>
        </div>
      )}
    </>
  );
};

export default ComponentOutline;
