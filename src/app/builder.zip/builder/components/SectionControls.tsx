// SectionControls.tsx

import React from 'react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Button } from '@/components/ui/button';
import { ArrowUp, ArrowDown, Copy, Trash2, Eye, EyeOff } from 'lucide-react';

type SectionControlsProps = {
  sectionId: string;
  index: number;
  totalSections: number;
  onMoveUp: () => void;
  onMoveDown: () => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onToggleVisibility: () => void;
  isVisible?: boolean;
};

export function SectionControls({
  sectionId,
  index,
  totalSections,
  onMoveUp,
  onMoveDown,
  onDuplicate,
  onDelete,
  onToggleVisibility,
  isVisible = true,
}: SectionControlsProps) {
  return (
    <TooltipProvider>
      <div className="absolute right-1 top-1 flex bg-zinc-800 p-1 rounded-md z-10">
        {/* Visibility Toggle */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              size="icon"
              variant="ghost"
              className="w-6 h-6 text-zinc-100"
              onClick={(e) => {
                e.stopPropagation();
                onToggleVisibility();
              }}
            >
              {isVisible === false ? (
                <Eye className="w-4 h-4" />
              ) : (
                <EyeOff className="w-4 h-4" />
              )}
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            {isVisible === false ? 'Show Section' : 'Hide Section'}
          </TooltipContent>
        </Tooltip>

        {/* Move Up */}
        {index > 0 && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                size="icon"
                variant="ghost"
                className="w-6 h-6 text-zinc-100"
                onClick={(e) => {
                  e.stopPropagation();
                  onMoveUp();
                }}
              >
                <ArrowUp className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Move Up</TooltipContent>
          </Tooltip>
        )}

        {/* Move Down */}
        {index < totalSections - 1 && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                size="icon"
                variant="ghost"
                className="w-6 h-6 text-zinc-100"
                onClick={(e) => {
                  e.stopPropagation();
                  onMoveDown();
                }}
              >
                <ArrowDown className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Move Down</TooltipContent>
          </Tooltip>
        )}

        {/* Duplicate */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              size="icon"
              variant="ghost"
              className="w-6 h-6 text-zinc-100"
              onClick={(e) => {
                e.stopPropagation();
                onDuplicate();
              }}
            >
              <Copy className="w-4 h-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Duplicate</TooltipContent>
        </Tooltip>

        {/* Delete */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              size="icon"
              variant="ghost"
              className="w-6 h-6 text-red-400 hover:text-red-600"
              onClick={(e) => {
                e.stopPropagation();
                onDelete();
              }}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Delete</TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}
