// -- File: components/NarrowSidebarButtons.tsx --

"use client";

import React from 'react';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Layers, Settings } from 'lucide-react';

export type ActiveSidebar = 'layers' | 'settings' | 'global-settings' | null;

interface NarrowSidebarButtonsProps {
  active: ActiveSidebar;
  onToggle: (type: ActiveSidebar) => void;
  onOpenGlobalSettings?: () => void;
}

export function NarrowSidebarButtons({ active, onToggle, onOpenGlobalSettings }: NarrowSidebarButtonsProps) {
  return (
    <div className="w-12 bg-gray-100 flex flex-col items-center py-4 border-r">
      <Tooltip>
        <TooltipTrigger asChild>
          <div role="button" tabIndex={0} onClick={() => onToggle('layers')}>
            <Button
              variant={active === 'layers' ? 'default' : 'ghost'}
              size="icon"
              asChild
            >
              <div>
                <Layers />
              </div>
            </Button>
          </div>
        </TooltipTrigger>
        <TooltipContent>Layers</TooltipContent>
      </Tooltip>

      {/* Global Settings Button */}
      <Tooltip>
        <TooltipTrigger asChild>
          <div role="button" tabIndex={0} onClick={() => onToggle('global-settings')}>
            <Button
              variant={active === 'global-settings' ? 'default' : 'ghost'}
              size="icon"
              asChild
            >
              <div>
                <Settings />
              </div>
            </Button>
          </div>
        </TooltipTrigger>
        <TooltipContent>Global Settings</TooltipContent>
      </Tooltip>
    </div>
  );
}
