import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X } from 'lucide-react';

interface GlobalSettingsPanelProps {
  contentRef: React.RefObject<HTMLIFrameElement>;
  onClose: () => void;
}

export function GlobalSettingsPanel({ contentRef, onClose }: GlobalSettingsPanelProps) {
  const handleGlobalSettingChange = (settingName: string, value: string) => {
    // Send global setting change to iframe
    contentRef.current?.contentWindow?.postMessage(
      {
        type: 'UPDATE_GLOBAL_SETTING',
        settingName,
        value
      },
      '*'
    );
  };

  return (
    <div className="p-4 space-y-4 relative">
      {/* Close Button */}
      <Button 
        variant="ghost" 
        size="icon" 
        className="absolute top-2 right-2"
        onClick={onClose}
      >
        <X className="h-4 w-4" />
      </Button>

      <h2 className="text-xl font-bold mb-4">Global Settings</h2>
      
      {/* Theme Settings */}
      <div className="space-y-2">
        <Label>Color Theme</Label>
        <Select 
          onValueChange={(value) => handleGlobalSettingChange('theme', value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select Theme" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="light">Light</SelectItem>
            <SelectItem value="dark">Dark</SelectItem>
            <SelectItem value="system">System Default</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      {/* Typography Settings */}
      <div className="space-y-2">
        <Label>Base Font Size</Label>
        <Select 
          onValueChange={(value) => handleGlobalSettingChange('baseFontSize', value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select Font Size" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="small">Small</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="large">Large</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      {/* Spacing Settings */}
      <div className="space-y-2">
        <Label>Global Spacing</Label>
        <Input 
          type="number" 
          placeholder="Spacing in px" 
          onChange={(e) => handleGlobalSettingChange('globalSpacing', e.target.value)}
        />
      </div>
      
      {/* Project-wide Settings */}
      <div className="space-y-2">
        <Label>Project Name</Label>
        <Input 
          type="text" 
          placeholder="Enter project name" 
          onChange={(e) => handleGlobalSettingChange('projectName', e.target.value)}
        />
      </div>
    </div>
  );
}
