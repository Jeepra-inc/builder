"use client";

import React, { useState, useEffect } from "react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
  DragOverlay,
} from "@dnd-kit/core";
import {
  SortableContext,
  rectSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

import { Copy, Trash2, GripVertical, Eye, EyeOff, Plus } from "lucide-react";

// Your imports
import { Section, SectionType } from "../../builder";
import { BlockRegistry } from "@/app/builder/elements/blocks/registry";
import { createDefaultBlock } from "@/app/builder/elements/blocks/registry";

// Dynamically get block types/limits/default blocks from the section type
import { getSectionBlockConfig } from "@/app/builder/elements/sections/section-registry";

interface BlockSettings {
  id: string;
  type: string;
  [key: string]: any;
}

interface SortableItemProps {
  section: Section;
  onHover: (id: string | null) => void;
  onSelectSection?: (id: string) => void;
  onDuplicate?: () => void;
  onDelete?: () => void;
  onToggleVisibility: (section: Section) => void;
  onBlockReorder?: (sectionId: string, newBlocks: BlockSettings[]) => void;
  isOverlay?: boolean;
  isDragging?: boolean;
  className?: string;
}

interface ExtendedSortableArguments {
  id: string;
  activationConstraint?: {
    type: "pointer" | "touch";
    activationMethod?: "pointer" | "touch";
  };
  type?: "pointer" | "touch";
  activationMethod?: "pointer" | "touch";
}

// We re-use this “plus popover” for adding blocks
function PlusPopoverButton({
  insertIndex,
  localBlocks,
  setLocalBlocks,
  section,
  blockTypes,
  blockTypeLimits,
}: {
  insertIndex: number;
  localBlocks: BlockSettings[];
  setLocalBlocks: React.Dispatch<React.SetStateAction<BlockSettings[]>>;
  section: Section;
  blockTypes: string[];
  blockTypeLimits: Record<string, number>;
}) {
  function handleBlockInsert(type: string) {
    // Enforce block limit
    const currentCount = localBlocks.filter((b) => b.type === type).length;
    const allowedMax = blockTypeLimits[type] ?? Infinity;
    if (currentCount >= allowedMax) {
      console.warn(`Limit for block type ${type} reached.`);
      return;
    }

    // Create & insert block
    const newBlock = createDefaultBlock(type as keyof typeof BlockRegistry);
    const updatedBlocks = [...localBlocks];
    updatedBlocks.splice(insertIndex, 0, newBlock);
    setLocalBlocks(updatedBlocks);

    // Dispatch global sync
    const updateEvent = new CustomEvent("section-blocks-updated", {
      detail: { sectionId: section.id, blocks: updatedBlocks },
    });
    window.dispatchEvent(updateEvent);

    // Sync with iframe
    const iframeElement = document.getElementById(
      "builder-iframe"
    ) as HTMLIFrameElement;
    if (iframeElement?.contentWindow) {
      iframeElement.contentWindow.postMessage(
        {
          type: "SECTION_BLOCKS_UPDATED",
          sectionId: section.id,
          blocks: updatedBlocks,
        },
        "*"
      );
    }
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <div className="flex items-center justify-center py-1 cursor-pointer hover:bg-gray-100 rounded">
          <Plus className="w-4 h-4 text-gray-500" />
        </div>
      </PopoverTrigger>
      <PopoverContent className="w-64 p-2">
        <div className="grid grid-cols-3 gap-2">
          {Object.entries(BlockRegistry)
            .filter(([type]) => blockTypes.includes(type))
            .filter(([type]) => {
              const currentCount = localBlocks.filter((b) => b.type === type).length;
              const maxAllowed = blockTypeLimits[type] ?? Infinity;
              return currentCount < maxAllowed;
            })
            .map(([type, { icon: BlockIcon }]) => (
              <button
                key={type}
                className="flex flex-col items-center p-2 hover:bg-gray-100 rounded"
                onClick={() => handleBlockInsert(type)}
              >
                {BlockIcon ? (
                  <BlockIcon className="w-6 h-6 mb-1 text-gray-600" />
                ) : (
                  <Plus className="w-6 h-6 mb-1 text-gray-600" />
                )}
                <span className="text-xs capitalize">{type}</span>
              </button>
            ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}

export function SortableItem({
  section,
  onHover,
  onSelectSection,
  onDuplicate,
  onDelete,
  onToggleVisibility,
  onBlockReorder,
  isOverlay = false,
  isDragging = false,
  className = "",
}: SortableItemProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isBlocksExpanded, setIsBlocksExpanded] = useState(false);
  const [localBlocks, setLocalBlocks] = useState<BlockSettings[]>([]);

  // Dynamically get config for this section type
  const { blockTypes, blockTypeLimits, defaultBlocks } = getSectionBlockConfig(
    section.type
  );

  // DRAG & DROP sensors
  const blockSensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor)
  );

  // Outer DnD for the entire section
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({
    id: section.id,
    disabled: isOverlay,
    activationConstraint: {
      type: "pointer",
      activationMethod: "pointer",
    },
  } as ExtendedSortableArguments);

  // Remove scale from transform
  const style = {
    transform: transform
      ? CSS.Transform.toString({ ...transform, scaleX: 1, scaleY: 1 })
      : undefined,
    transition,
  };

  const dragHandleAttributes = { ...attributes, ...listeners };

  // Populate local blocks on mount / section change
  useEffect(() => {
    setLocalBlocks(getBlocksForSection(section));
  }, [section]);

  // Listen for global or iframe block updates
  useEffect(() => {
    const handleBlockUpdate = (event: MessageEvent) => {
      const iframeElement = document.getElementById(
        "builder-iframe"
      ) as HTMLIFrameElement;
      if (event.source !== iframeElement?.contentWindow) return;

      if (event.data.type === "SECTION_BLOCKS_UPDATED") {
        if (event.data.sectionId === section.id) {
          setLocalBlocks(event.data.blocks);
          const updateEvent = new CustomEvent("section-blocks-updated", {
            detail: { sectionId: section.id, blocks: event.data.blocks },
          });
          window.dispatchEvent(updateEvent);
        }
      }
    };
    window.addEventListener("message", handleBlockUpdate);

    const handleBlocksUpdated = (event: CustomEvent) => {
      if (event.detail.sectionId === section.id) {
        if (!section.settings) {
          section.settings = {};
        }
        section.settings.blocks = event.detail.blocks;
        section.blocks = event.detail.blocks;
        setLocalBlocks(event.detail.blocks);
      }
    };
    window.addEventListener("section-blocks-updated", handleBlocksUpdated as EventListener);

    return () => {
      window.removeEventListener("message", handleBlockUpdate);
      window.removeEventListener("section-blocks-updated", handleBlocksUpdated as EventListener);
    };
  }, [section.id, section]);

  // Merges existing blocks with default blocks if none
  function getBlocksForSection(section: Section): BlockSettings[] {
    const possibleBlocks = [
      section.settings?.blocks,
      section.blocks,
      section.settings?.items?.[0]?.blocks,
    ];
    const existingBlocks =
      possibleBlocks.find((arr) => arr && arr.length > 0) || [];

    console.log("Block Detection Debug:", {
      sectionId: section.id,
      sectionType: section.type,
      possibleBlocks,
      existingBlocks,
      defaultBlocks,
    });

    // If none, use config defaultBlocks
    const finalBlocks = existingBlocks.length > 0 ? existingBlocks : defaultBlocks || [];
    return finalBlocks.map((block, i) => ({
      ...block,
      id: block.id || `${section.id}-block-${i}`,
    }));
  }

  // Nested block
  const SortableBlockItem = ({ block }: { block: BlockSettings }) => {
    const {
      attributes,
      listeners,
      setNodeRef,
      transform,
      transition,
      isDragging,
    } = useSortable({ id: block.id });

    const fallbackBlockIcon = React.forwardRef<
      SVGSVGElement,
      React.SVGProps<SVGSVGElement>
    >((props, ref) => <Plus {...props} ref={ref} />);

    const registryEntry = BlockRegistry[block.type];
    const BlockIcon = registryEntry?.icon || fallbackBlockIcon;

    const blockStyle = {
      transform: transform
        ? CSS.Transform.toString({ ...transform, scaleX: 1, scaleY: 1 })
        : undefined,
      transition,
      opacity: isDragging ? 0.5 : 1,
      cursor: "move",
    };

    return (
      <div
        ref={setNodeRef}
        style={blockStyle}
        className="flex items-center py-1 px-2 text-xs text-gray-600 hover:bg-blue-50 rounded"
      >
        <div {...attributes} {...listeners} className="cursor-move mr-2">
          <GripVertical className="w-3 h-3 text-gray-400" />
        </div>
        <BlockIcon className="mr-2 w-3 h-3 text-gray-500" />
        <span>{block.type || "Block"}</span>
      </div>
    );
  };

  // Handle nested block reorder
  const handleBlockDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    const oldIndex = localBlocks.findIndex((b) => b.id === active.id);
    const newIndex = localBlocks.findIndex((b) => b.id === over.id);
    if (oldIndex === -1 || newIndex === -1) return;

    const updatedBlocks = [...localBlocks];
    const [reorderedBlock] = updatedBlocks.splice(oldIndex, 1);
    updatedBlocks.splice(newIndex, 0, reorderedBlock);

    setLocalBlocks(updatedBlocks);

    const updateEvent = new CustomEvent("section-blocks-updated", {
      detail: { sectionId: section.id, blocks: updatedBlocks },
    });
    window.dispatchEvent(updateEvent);

    // Sync with iframe
    const iframeElement = document.getElementById("builder-iframe") as HTMLIFrameElement;
    if (iframeElement?.contentWindow) {
      iframeElement.contentWindow.postMessage(
        {
          type: "REORDER_SECTION_BLOCKS",
          sectionId: section.id,
          blocks: updatedBlocks,
        },
        "*"
      );
    }

    // If callback is provided
    if (onBlockReorder) {
      onBlockReorder(section.id, updatedBlocks);
    }
  };

  // Toggle block expansion
  function handleToggleBlocks(e: React.MouseEvent) {
    e.stopPropagation();
    setIsBlocksExpanded((prev) => !prev);
  }

  // Click entire section
  function handleSectionClick() {
    const event = new CustomEvent("open-section-settings", {
      detail: { sectionId: section.id },
    });
    window.dispatchEvent(event);
    onSelectSection?.(section.id);
  }

  // We remove the `hasBlocks` check so the plus button always shows for `Card` sections.
  return (
    <div>
      {/* === MAIN SECTION ROW === */}
      <div
        ref={setNodeRef}
        style={style}
        className={`p-2 rounded-md cursor-pointer transition-colors duration-200
          ${isOverlay ? "" : isHovered ? "bg-blue-50" : "bg-gray-100/50"}
          ${className}`}
        onClick={handleSectionClick}
        onMouseEnter={() => {
          setIsHovered(true);
          onHover(section.id);
        }}
        onMouseLeave={() => {
          setIsHovered(false);
          onHover(null);
        }}
      >
        <div className="flex items-center justify-between w-full">
          {/* Drag handle + label */}
          <div className="flex items-center space-x-2 flex-grow">
            <div
              {...dragHandleAttributes}
              className="cursor-move w-4 h-4 text-gray-400 mr-2"
            >
              <GripVertical className="w-4 h-4" />
            </div>
            <span className="text-sm font-medium flex-grow">{section.type}</span>
          </div>

          {/* Hover actions */}
          {!isOverlay && isHovered && (
            <div className="flex space-x-2 ml-auto">
              {/* 
                Always show the expand/collapse button for Card 
                (removing "hasBlocks" condition).
              */}
              {section.type === SectionType.Card && (
                <Tooltip>
                  <TooltipTrigger>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-6 h-2"
                      onClick={handleToggleBlocks}
                    >
                      {isBlocksExpanded ? "–" : "+"}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    {isBlocksExpanded ? "Collapse Blocks" : "Show Blocks"}
                  </TooltipContent>
                </Tooltip>
              )}

              {/* Visibility Toggle */}
              <Tooltip>
                <TooltipTrigger>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-6 h-4"
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleVisibility(section);
                    }}
                  >
                    {section.isVisible ? (
                      <Eye className="w-6 h-4" />
                    ) : (
                      <EyeOff className="w-6 h-4" />
                    )}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  {section.isVisible ? "Hide" : "Show"}
                </TooltipContent>
              </Tooltip>

              {/* Duplicate */}
              <Tooltip>
                <TooltipTrigger>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-6 h-4"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDuplicate?.();
                    }}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Duplicate</TooltipContent>
              </Tooltip>

              {/* Delete */}
              <Tooltip>
                <TooltipTrigger>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-6 h-4"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete?.();
                    }}
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Delete</TooltipContent>
              </Tooltip>
            </div>
          )}
        </div>
      </div>

      {/* === BLOCKS (nested DnD) === */}
      {isBlocksExpanded && section.type === SectionType.Card && (
        <DndContext
          sensors={blockSensors}
          collisionDetection={closestCenter}
          onDragEnd={handleBlockDragEnd}
        >
          <SortableContext items={localBlocks.map((b) => b.id)} strategy={rectSortingStrategy}>
            <div className="pl-6 mt-1 space-y-1">
              {localBlocks.map((block, index) => (
                <React.Fragment key={block.id}>
                  <SortableBlockItem block={block} />
                  {/* Insert block at index+1 */}
                  <PlusPopoverButton
                    insertIndex={index + 1}
                    localBlocks={localBlocks}
                    setLocalBlocks={setLocalBlocks}
                    section={section}
                    blockTypes={blockTypes}
                    blockTypeLimits={blockTypeLimits}
                  />
                </React.Fragment>
              ))}
              {/* Final plus button at the end */}
              <PlusPopoverButton
                insertIndex={localBlocks.length}
                localBlocks={localBlocks}
                setLocalBlocks={setLocalBlocks}
                section={section}
                blockTypes={blockTypes}
                blockTypeLimits={blockTypeLimits}
              />
            </div>
          </SortableContext>

          <DragOverlay>
            <div className="flex items-center py-1 px-2 text-xs text-gray-600 hover:bg-blue-50 rounded">
              <div className="cursor-move mr-2">
                <GripVertical className="w-3 h-3 text-gray-400" />
              </div>
              <Plus className="mr-2 w-3 h-3 text-gray-500" />
              <span>Block</span>
            </div>
          </DragOverlay>
        </DndContext>
      )}
    </div>
  );
}
