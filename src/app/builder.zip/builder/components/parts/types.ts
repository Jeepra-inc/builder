// -- File: types.ts --

export type Section = import("/Users/nisheshp/Downloads/builder/src/app/builder/builder").Section;

export type ViewportSize = 'mobile' | 'tablet' | 'desktop' | 'fullscreen';

export type ActiveSidebar = 'layers' | 'settings' | 'global-settings' | null;
