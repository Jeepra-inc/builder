// -- File: components/ViewportSizeControls.tsx --

"use client";

import React from 'react';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Smartphone, Tablet, Monitor, Maximize2 } from 'lucide-react';
import { ViewportSize } from './types';

interface ViewportSizeControlsProps {
  currentSize: ViewportSize;
  onChange: (size: ViewportSize) => void;
}

export function ViewportSizeControls({
  currentSize,
  onChange,
}: ViewportSizeControlsProps) {
  return (
    <div className="flex items-center space-x-1">
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant={currentSize === 'mobile' ? 'default' : 'outline'}
            size="icon"
            className="w-8 h-8"
            onClick={() => onChange('mobile')}
          >
            <Smartphone className="w-4 h-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>Mobile View</TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant={currentSize === 'tablet' ? 'default' : 'outline'}
            size="icon"
            className="w-8 h-8"
            onClick={() => onChange('tablet')}
          >
            <Tablet className="w-4 h-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>Tablet View</TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant={currentSize === 'desktop' ? 'default' : 'outline'}
            size="icon"
            className="w-8 h-8"
            onClick={() => onChange('desktop')}
          >
            <Monitor className="w-4 h-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>Desktop View</TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant={currentSize === 'fullscreen' ? 'default' : 'outline'}
            size="icon"
            className="w-8 h-8"
            onClick={() => onChange('fullscreen')}
          >
            <Maximize2 className="w-4 h-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>Fullscreen View</TooltipContent>
      </Tooltip>
    </div>
  );
}
