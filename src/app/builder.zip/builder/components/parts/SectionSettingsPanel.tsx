// -- File: components/SectionSettingsPanel.tsx --

"use client";

import React from 'react';
import { Section } from '@/app/builder/builder';
import { SectionSettingsRenderer } from '@/app/builder/components/section-settings-renderer';

interface SectionSettingsPanelProps {
  selectedSectionId: string | null;
  sections: Section[];
  contentRef: React.RefObject<HTMLIFrameElement>;
  onToggleLayers: () => void;
}

export function SectionSettingsPanel({
  selectedSectionId,
  sections,
  contentRef,
  onToggleLayers,
}: SectionSettingsPanelProps) {
  if (!selectedSectionId) return null;

  const section = sections.find((s) => s.id === selectedSectionId);
  if (!section) return null;

  return (
    <div className="p-4 overflow-y-auto">
      <div className="flex items-center mb-4">
        <button
          onClick={onToggleLayers}
          className="mr-4 text-gray-600 hover:text-gray-900 transition-colors"
          aria-label="Back to Layers"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
        </button>
        <h2 className="text-lg font-semibold">Section Settings</h2>
      </div>
      <SectionSettingsRenderer
        section={section}
        onUpdateSection={(updates) => {
          if (contentRef.current?.contentWindow) {
            contentRef.current.contentWindow.postMessage(
              {
                type: 'UPDATE_SECTION',
                sectionId: selectedSectionId,
                updates,
              },
              '*'
            );
          }
        }}
      />
    </div>
  );
}
