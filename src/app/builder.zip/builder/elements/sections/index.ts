// sections/index.ts
import { Theme } from '@/app/builder/builder';
import { SectionType } from '@/app/builder/builder';
import { sectionRegistry } from './section-registry';

// Dynamically import all section modules using require.context
const sectionsContext = require.context('./', true, /^\.\/[^/]+\/index\.ts$/) as {
  keys(): string[];
  (id: string): any;
  resolve(id: string): string;
};

// Initialize objects to hold schemas, components, and special sections
const schemas: Record<string, any> = {};
const components: Record<string, React.ComponentType<any>> = {};

// Function to find placeholder image
const findPlaceholderImage = (componentName: string, sectionFolder: string) => {
  // Possible placeholder file names
  const placeholderNames = [
    `${componentName}-placeholder.svg`,
    `${componentName}Placeholder.svg`,
    'placeholder.svg'
  ];

  // Try to find the placeholder in the section's placeholders folder
  for (const placeholderName of placeholderNames) {
    const placeholderPath = `/sections/${sectionFolder}/placeholders/${placeholderName}`;
    
    // In a real webpack context, you'd use require.context or similar
    // Here we're assuming the file might exist
    return placeholderPath;
  }

  // Fallback to a global default placeholder
  return '/placeholders/default-placeholder.svg';
};

// Aggregate exports from each section module
sectionsContext.keys().forEach((path) => {
  const module = sectionsContext(path);

  // Extract folder name from the path (e.g., './banner/index.ts' -> 'banner')
  const folder = path.split('/')[1];

  // Collect schemas, components, and special sections
  Object.keys(module).forEach((exportKey) => {
    if (exportKey.endsWith('Schema')) {
      const componentName = exportKey.replace('Schema', '').toLowerCase();
      schemas[componentName] = module[exportKey];
    }
    
    // Detect components more robustly
    if (typeof module[exportKey] === 'function' && exportKey.endsWith('Component')) {
      const componentName = exportKey.replace('Component', '').toLowerCase();
      components[componentName] = module[exportKey];
    }
    
    // Handle special sections
    if (exportKey === 'bannerSpecialSections') {
      Object.assign(components, module[exportKey]);
    }
  });

  // Fallback: if default export is a valid component, add it
  if (module.default && typeof module.default === 'function') {
    const defaultComponentName = module.default.name.replace('Component', '').toLowerCase();
    components[defaultComponentName] = module.default;
  }
});

// Dynamically register sections
const registerSections = () => {
  Object.entries(components).forEach(([componentName, component]) => {
    const schema = schemas[componentName];

    // Determine section type and name
    const sectionType = componentName as SectionType;
    const sectionName = `${componentName.charAt(0).toUpperCase() + componentName.slice(1)} Section`;

    // Special handling for banner components to ensure they're in the same group
    const group = componentName.includes('banner') ? 'banner' : componentName;

    // Find the corresponding section folder
    const sectionFolder = Object.keys(sectionsContext.keys()).find(path => 
      path.includes(`/${componentName}/`) || path.includes(`/${group}/`)
    )?.split('/')[1] || componentName;

    // Register section
    sectionRegistry.registerSection({
      type: sectionType,
      name: sectionName,
      description: schema?.description || sectionName,
      group, 
      component,
      placeholderImage: findPlaceholderImage(componentName, sectionFolder)
    });
  });
};

registerSections();

// Generate sections configuration
const sectionsConfig = Object.entries(components).reduce((acc: Record<string, any>, [componentName, component]) => {
  const schema = schemas[componentName];

  acc[componentName] = {
    name: `${componentName.charAt(0).toUpperCase() + componentName.slice(1)} Section`,
    component,
    settings: schema?.settings || [],
  };

  return acc;
}, {});

// Merge any special sections
const finalSectionsConfig = {
  ...sectionsConfig,
};

// Export aggregated components and schemas
export const allSchemas = schemas;
export const allComponents = components;

// Export the aggregated sections as a Theme
export const sections: Theme = {
  id: 'default',
  name: 'Default Theme',
  sections: finalSectionsConfig,
};

// Optionally, export the Theme as the default export
export default sections;

// Export section registry for external access if needed
export { sectionRegistry };
