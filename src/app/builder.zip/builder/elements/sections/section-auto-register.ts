import { sectionRegistry } from './section-registry';
import { SectionType } from '@/app/builder/builder';
import { ComponentType } from 'react';
import { SectionSchema } from '@/app/builder/builder';
import { allComponents, allSchemas } from '@/app/builder/elements/sections';

export interface SectionRegistration {
  type: SectionType;
  name: string;
  component: ComponentType<any>;
  schema: SectionSchema;
  group?: string;
}

export function defineSectionModule(registration: SectionRegistration) {
  return registration;
}

// Dynamically import and register sections
export const autoRegisterSections = async () => {
  // Use the components from the main index file
  const componentKeys = Object.keys(allComponents);

  for (const componentKey of componentKeys) {
    try {
      const component = allComponents[componentKey];
      const schemaKey = `${componentKey.replace('Component', '')}Schema`;
      const schema = allSchemas[schemaKey];

      // Determine section type and name
      const sectionType = componentKey.replace('Component', '').toLowerCase() as SectionType;
      const sectionName = `${componentKey.replace('Component', '').charAt(0).toUpperCase() + componentKey.replace('Component', '').slice(1)} Section`;

      // Special handling for banner components to ensure they're in the same group
      const group = sectionType.includes('banner') ? 'banner' : (schema?.group || sectionType);

      // Register section
      sectionRegistry.registerSection({
        type: sectionType,
        name: sectionName,
        description: schema?.description || sectionName,
        group, 
        component,
        placeholderImage: `/sections/${sectionType.toLowerCase()}/placeholders/${sectionType.toLowerCase()}-placeholder.svg`
      });

    } catch (error) {
      console.error(`Error registering section for ${componentKey}:`, error);
    }
  }
};

// Auto-register sections when this module is imported
autoRegisterSections();
