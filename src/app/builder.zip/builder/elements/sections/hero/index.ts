import HeroComponent, { heroSchema } from './hero-component';
export { 
  HeroComponent, 
  heroSchema 
};
export default HeroComponent;
