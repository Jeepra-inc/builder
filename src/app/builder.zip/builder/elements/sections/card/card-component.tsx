import React, { useState, useEffect, useCallback, useRef } from 'react';
import { BlockRegistry, createDefaultBlock } from '@/app/builder/elements/blocks/registry';
import { SectionSchema, SectionComponentProps } from '@/app/builder/builder';
import { Card, CardContent } from '@/components/ui/card';
import { BlockAdditionWrapper } from '@/app/builder/components/hoc/with-block-addition';
import { BlockSettings } from '@/app/builder/elements/blocks/types';
import clsx from 'clsx';
import SectionWrapper from '@/app/builder/components/SectionWrapper';
import { Edit } from 'lucide-react';

export const cardSchema: SectionSchema = {
  name: 'Card Section',
  type: 'card',
  schema: [
    {
      id: 'blocks',
      type: 'multiselect',
      label: 'Card Blocks',
      description: 'Blocks to display in the card section',
      options: [
        { value: 'image', label: 'Image' },
        { value: 'heading', label: 'Heading' },
        { value: 'paragraph', label: 'Paragraph' }
      ]
    }
  ],
  settings: [
    {
      id: 'cardStyle',
      type: 'select',
      label: 'Card Style',
      options: [
        { value: 'default', label: 'Default' },
        { value: 'outlined', label: 'Outlined' },
        { value: 'elevated', label: 'Elevated' }
      ],
      default: 'default'
    },
    {
      id: 'backgroundColor',
      type: 'color',
      label: 'Background Color',
      default: '#ffffff'
    },
    {
      id: 'hello',
      type: 'text',
      label: 'hello',
      default: 'hello'
    }
  ]
};

export const CardComponent: React.FC<SectionComponentProps> & { schema?: SectionSchema } = ({ 
  section, 
  isEditing, 
  isSelected, 
  onUpdateSection,  
  className
}) => {
  // Debug logging for initial section state
  console.log('Initial Card Section State:', {
    sectionId: section.id,
    initialSettings: section.settings,
    initialBlocks: section.settings?.items?.[0]?.blocks
  });

  // Define block type limits and types first
  const blockTypes: Array<keyof typeof BlockRegistry> = ['heading', 'image', 'paragraph'];
  const blockTypeLimits: Record<keyof typeof BlockRegistry, number> = {
    heading: 2,
    paragraph: 4,
    image: 2
  };

  // Use a ref to track whether initial blocks have been set
  const initialBlocksSetRef = useRef(false);
  const prevBlocksRef = useRef<BlockSettings[]>([]);

  // Derive blocks from section settings, with fallback to default blocks
  const [blocks, setBlocks] = useState<BlockSettings[]>(() => {
    // Try to get blocks from section settings first
    const initialBlocks = section.settings?.items?.[0]?.blocks || [
      createDefaultBlock('heading'),
      createDefaultBlock('image'),
      createDefaultBlock('paragraph')
    ];

    // Explicitly set blocks in section settings and section object
    if (onUpdateSection) {
      onUpdateSection({
        ...section,
        settings: {
          ...section.settings,
          blocks: initialBlocks,
          items: [{ blocks: initialBlocks }]
        },
        blocks: initialBlocks
      });
    }

    // Store initial blocks in ref
    prevBlocksRef.current = initialBlocks;

    return initialBlocks;
  });

  // Memoized block modification functions
  const addBlock = useCallback((
    blockType: keyof typeof BlockRegistry, 
    index?: number, 
    defaultValues?: Partial<BlockSettings>
  ) => {
    // Prevent adding blocks beyond type limits
    const currentBlockCount = blocks.filter(block => block.type === blockType).length;
    const blockTypeLimit = blockTypeLimits[blockType];

    if (currentBlockCount >= blockTypeLimit) {
      console.warn(`Maximum limit of ${blockTypeLimit} blocks for type ${blockType} reached`);
      return;
    }

    // Create a new block with merged default values
    const newBlock = createDefaultBlock(blockType, defaultValues);
    const newBlocks = [...blocks];
    
    if (index !== undefined) {
      newBlocks.splice(index, 0, newBlock);
    } else {
      newBlocks.push(newBlock);
    }

    // Update blocks state
    setBlocks(newBlocks);

    // Debounce the section update to prevent multiple rapid updates
    const updateSection = () => {
      const updatedSection = {
        ...section,
        settings: {
          ...section.settings,
          items: [{
            id: section.id,
            title: 'Card Section',
            content: '',
            blocks: newBlocks
          }]
        }
      };

      onUpdateSection(updatedSection);
    };

    // Use setTimeout to debounce the update
    setTimeout(updateSection, 100);
  }, [blocks, section, onUpdateSection, blockTypeLimits]);

  // Synchronize blocks with section settings when component mounts or blocks change
  useEffect(() => {
    // Prevent unnecessary updates
    const currentItemBlocks = section.settings?.items?.[0]?.blocks || [];
    
    // Deep comparison to check if blocks have actually changed
    const blocksHaveChanged = currentItemBlocks.length !== blocks.length || 
      blocks.some((block, index) => 
        JSON.stringify(block) !== JSON.stringify(currentItemBlocks[index])
      );

    console.log('Block Synchronization Debug:', {
      currentItemBlocks,
      newBlocks: blocks,
      blocksHaveChanged,
      initialBlocksSetRef: initialBlocksSetRef.current
    });

    // Only update if blocks are different and not already set
    if (blocksHaveChanged && !initialBlocksSetRef.current) {
      const updatedSection = {
        ...section,
        settings: {
          ...section.settings,
          items: [{
            id: section.id,
            title: 'Card Section',
            content: '',
            blocks: blocks
          }]
        }
      };

      console.log('Updating Section with Blocks:', {
        updatedSection,
        blocks
      });

      // Use a microtask to prevent potential update loops
      queueMicrotask(() => {
        onUpdateSection(updatedSection);
      });

      initialBlocksSetRef.current = true;
    }

    // Update previous blocks ref
    prevBlocksRef.current = blocks;
  }, [blocks, onUpdateSection, section]);

  // Function to count blocks of a specific type
  const countBlocksByType = useCallback((blockType: keyof typeof BlockRegistry): number => {
    return blocks.filter(block => block.type === blockType).length;
  }, [blocks]);

  const removeBlock = useCallback((blockId: string) => {
    const newBlocks = blocks.filter(block => block.id !== blockId);
    setBlocks(newBlocks);
    onUpdateSection({
      ...section,
      settings: {
        ...section.settings,
        items: [{
          id: section.id,
          title: 'Card Section',
          content: '',
          blocks: newBlocks
        }]
      }
    });
  }, [blocks, section, onUpdateSection]);

  const updateBlock = useCallback((updatedBlock: BlockSettings) => {
    const newBlocks = blocks.map(block => 
      block.id === updatedBlock.id ? updatedBlock : block
    );
    setBlocks(newBlocks);
    onUpdateSection({
      ...section,
      settings: {
        ...section.settings,
        items: [{
          id: section.id,
          title: 'Card Section',
          content: '',
          blocks: newBlocks
        }]
      }
    });
  }, [blocks, section, onUpdateSection]);

  // Check if all block type limits have been reached
  const hasReachedAllBlockLimits = blockTypes.every(
    blockType => countBlocksByType(blockType) >= blockTypeLimits[blockType]
  );

  // Modify block types to only show those that haven't reached their limit
  const availableBlockTypes = blockTypes.filter(
    blockType => countBlocksByType(blockType) < blockTypeLimits[blockType]
  );

  // Default values for new blocks
  const defaultBlockValues = {
    paragraph: { 
      id: '', 
      type: 'paragraph', 
      content: 'New Paragraph Text' 
    },
    image: { 
      id: '', 
      type: 'image', 
      src: '/placeholder-image.jpg', 
      alt: 'New Image' 
    },
    heading: { 
      id: '', 
      type: 'heading', 
      content: 'New Heading' 
    }
  };

  const [hoveredBlockId, setHoveredBlockId] = useState<string | null>(null);
  const [hoveredSection, setHoveredSection] = useState<boolean>(false);
  const [activePopoverIndex, setActivePopoverIndex] = useState<number | null>(null);
  const [lastEditedBlockId, setLastEditedBlockId] = useState<string | null>(null);
  const [interactionCount, setInteractionCount] = useState(0);
  const [lastInteractionTimestamp, setLastInteractionTimestamp] = useState(0);

  // Global event handler to reset interactions
  const resetInteractions = useCallback(() => {
    console.log('Resetting interactions:', {
      currentHoveredBlockId: hoveredBlockId,
      currentActivePopoverIndex: activePopoverIndex,
      interactionCount: interactionCount
    });

    // Reset pointer events on body and iframes
    document.body.style.pointerEvents = 'auto';
    document.querySelectorAll('iframe').forEach(iframe => {
      (iframe as HTMLElement).style.pointerEvents = 'auto';
    });

    // Reset state
    setActivePopoverIndex(null);
  }, [hoveredBlockId, activePopoverIndex, interactionCount]);

  // Add global event listeners
  useEffect(() => {
    // Add click listener to reset interactions
    const handleGlobalClick = (e: MouseEvent) => {
      console.log('Global click event:', {
        target: e.target,
        currentTime: Date.now(),
        lastInteractionTimestamp: lastInteractionTimestamp
      });
      resetInteractions();
    };

    // Add keydown listener to reset on Escape
    const handleEscapeKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        console.log('Escape key pressed, resetting interactions');
        resetInteractions();
      }
    };

    // Add listeners
    document.addEventListener('click', handleGlobalClick);
    document.addEventListener('keydown', handleEscapeKey);

    // Cleanup listeners
    return () => {
      document.removeEventListener('click', handleGlobalClick);
      document.removeEventListener('keydown', handleEscapeKey);
    };
  }, [resetInteractions, lastInteractionTimestamp]);

  const resolvedSettings = {
    cardStyle: section.settings?.cardStyle || 'default',
    backgroundColor: section.settings?.backgroundColor || '#ffffff',
    hello: section.settings?.hello || 'Nishesh'
  };

  const handleEditSettings = (blockId: string, e: React.MouseEvent) => {
    // Minimal event handling
    if (e.target instanceof HTMLElement) {
      e.target.focus();
    }

    // Reset pointer events
    document.body.style.pointerEvents = 'auto';
    document.querySelectorAll('iframe').forEach(iframe => {
      (iframe as HTMLElement).style.pointerEvents = 'auto';
    });
  };

  return (
    <SectionWrapper 
      section={section} 
      isEditing={isEditing} 
      isSelected={isSelected} 
      className={className}
      onMouseEnter={() => setHoveredSection(true)}
      onMouseLeave={() => setHoveredSection(false)}
      renderEditButton={() => (
        <button 
          type="button"
          onClick={(e) => handleEditSettings(section.id, e)}
          className="absolute top-2 right-2 z-50 p-1 hover:bg-gray-100 rounded"
        >
          <Edit className="w-4 h-4 text-gray-600" />
        </button>
      )}
    >
      <Card 
        className={clsx(
          'w-full max-w-4xl mx-auto shadow-xl rounded-xl overflow-hidden',
          {
            'border-2 border-gray-200': resolvedSettings.cardStyle === 'outlined',
            'shadow-xl': resolvedSettings.cardStyle === 'elevated'
          },
          className
        )}
        style={{ 
          backgroundColor: resolvedSettings.backgroundColor 
        }}
      >
        <CardContent className="p-4 space-y-4">
          <h1>{resolvedSettings.hello}</h1>
          {blocks.map((block, index) => {
            const BlockComponent = BlockRegistry[block.type].component;

            return (
              <div 
                key={block.id}
                className={clsx(
                  'transition-all duration-200 ease-in-out',
                  {
                    'outline outline-2 outline-blue-500': hoveredBlockId === block.id,
                    'outline outline-1 outline-dashed outline-gray-400':
                      hoveredSection && hoveredBlockId !== block.id
                  }
                )}
                onMouseEnter={() => setHoveredBlockId(block.id)}
                onMouseLeave={() => setHoveredBlockId(null)}
              >
                <BlockAdditionWrapper
                  index={index}
                  isHovered={hoveredBlockId === block.id}
                  activePopoverIndex={activePopoverIndex}
                  setActivePopoverIndex={setActivePopoverIndex}
                  setHoveredBlockId={setHoveredBlockId}
                  availableBlockTypes={availableBlockTypes}
                  addBlock={addBlock}
                  hasReachedAllBlockLimits={hasReachedAllBlockLimits}
                  defaultBlockValues={defaultBlockValues}
                >
                  <BlockComponent 
                    block={block}
                    onUpdate={(updatedBlock: BlockSettings) => {
                      updateBlock(updatedBlock);
                    }}
                    onDelete={() => {
                      removeBlock(block.id);
                    }}
                    onMoveUp={index > 0 ? () => {
                      const newBlocks = [...blocks];
                      [newBlocks[index], newBlocks[index - 1]] = [newBlocks[index - 1], newBlocks[index]];
                      setBlocks(newBlocks);
                      onUpdateSection({
                        ...section,
                        settings: {
                          ...section.settings,
                          items: [{
                            id: section.id,
                            title: 'Card Section',
                            content: '',
                            blocks: newBlocks
                          }]
                        }
                      });
                    } : undefined}
                    onMoveDown={index < blocks.length - 1 ? () => {
                      const newBlocks = [...blocks];
                      [newBlocks[index], newBlocks[index + 1]] = [newBlocks[index + 1], newBlocks[index]];
                      setBlocks(newBlocks);
                      onUpdateSection({
                        ...section,
                        settings: {
                          ...section.settings,
                          items: [{
                            id: section.id,
                            title: 'Card Section',
                            content: '',
                            blocks: newBlocks
                          }]
                        }
                      });
                    } : undefined}
                    renderEditButton={() => (
                      <button 
                        type="button"
                        onClick={(e) => handleEditSettings(block.id, e)}
                        className="absolute top-2 right-2 z-50 p-1 hover:bg-gray-100 rounded"
                      >
                        <Edit className="w-4 h-4 text-gray-600" />
                      </button>
                    )}
                  />
                </BlockAdditionWrapper>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </SectionWrapper>
  );
};

CardComponent.schema = cardSchema;
