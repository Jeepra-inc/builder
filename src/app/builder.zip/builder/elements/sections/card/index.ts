import { CardComponent, cardSchema } from './card-component';
export { 
  CardComponent, 
  cardSchema 
};

export default CardComponent;
