// src/section-registry.ts
import { SectionType } from '@/app/builder/builder';
import { ComponentType } from 'react';

export interface SectionInfo {
  type: SectionType;
  name: string;
  description: string;
  group: string;
  component: ComponentType<any>;
  placeholderImage: string;
  defaultContent?: Record<string, any>;
}

export class SectionRegistry {
  private static _instance: SectionRegistry;
  private _sections: Map<SectionType, SectionInfo> = new Map();

  private constructor() {}

  public static getInstance(): SectionRegistry {
    if (!SectionRegistry._instance) {
      SectionRegistry._instance = new SectionRegistry();
    }
    return SectionRegistry._instance;
  }

  // Register a new section
  public registerSection(section: SectionInfo) {
    this._sections.set(section.type, section);
  }

  // Get all sections
  public getAllSections(): SectionInfo[] {
    return Array.from(this._sections.values());
  }

  // Get sections by group
  public getSectionsByGroup(group: string): SectionInfo[] {
    return this.getAllSections().filter(section => section.group === group);
  }

  // Get a specific section by type
  public getSection(type: SectionType): SectionInfo | undefined {
    return this._sections.get(type);
  }

  // Get all unique groups
  public getGroups(): string[] {
    return [...new Set(this.getAllSections().map(section => section.group))];
  }
}

// Singleton instance for easy access
export const sectionRegistry = SectionRegistry.getInstance();

// Add block configuration retrieval function
export function getSectionBlockConfig(sectionType: SectionType) {
  // Default configuration if no specific section is found
  const defaultConfig = {
    blockTypes: [],
    blockTypeLimits: {},
    defaultBlocks: []
  };

  // Get the specific section configuration
  const section = sectionRegistry.getSection(sectionType);
  
  // If no section found, return default config
  if (!section) {
    console.warn(`No section configuration found for type: ${sectionType}`);
    return defaultConfig;
  }

  // Specific configuration for different section types
  switch(sectionType) {
    case 'card':
      return {
        blockTypes: ['heading', 'image', 'paragraph'],
        blockTypeLimits: {
          'heading': 2,
          'image': 2,
          'paragraph': 4
        },
        defaultBlocks: [
          { type: 'heading', id: `heading-default-${Date.now()}` },
          { type: 'image', id: `image-default-${Date.now()}` },
          { type: 'paragraph', id: `paragraph-default-${Date.now()}` }
        ]
      };
    
    // Add more section types as needed
    default:
      return {
        blockTypes: ['text', 'image', 'button'], // Example block types
        blockTypeLimits: {
          'text': 3,
          'image': 2,
          'button': 1
        },
        defaultBlocks: [] // You can add default blocks if needed
      };
  }
}
