import { Section, SectionSchema } from '@/app/builder/builder';

export interface SectionProps {
  settings: Section['settings'];
  schema?: SectionSchema;
}


