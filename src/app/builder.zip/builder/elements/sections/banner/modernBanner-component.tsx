// src/sections/banner/modernBanner-component.tsx
import React, { FC } from 'react';
import { Section, SectionType, SectionSchema } from '@/app/builder/builder';
import clsx from 'clsx';
import SectionWrapper from '@/app/builder/components/SectionWrapper';

export const modernBannerSchema: SectionSchema = {
  name: 'ModernBanner',
  type: SectionType.ModernBanner,
  schema: [
    {
      id: 'headline',
      type: 'text',
      label: 'Headline',
      default: 'Elevate Your Business'
    },
    {
      id: 'subheadline',
      type: 'textarea',
      label: 'Subheadline',
      default: 'Discover innovative solutions that transform your workflow'
    },
    {
      id: 'ctaButtonUrl',
      type: 'url',
      label: 'CTA Button URL',
      default: '#'
    }
  ],
  settings: [
    {
      id: 'layout',
      type: 'select',
      label: 'Layout',
      options: [
        { value: 'centered', label: 'Centered' },
        { value: 'split', label: 'Split' }
      ],
      default: 'centered'
    },
    {
      id: 'backgroundColor',
      type: 'color',
      label: 'Background Color',
      default: '#1a1a2e'
    },
    {
      id: 'textColor',
      type: 'color',
      label: 'Text Color',
      default: '#ffffff'
    },
    {
      id: 'ctaButtonColor',
      type: 'color',
      label: 'CTA Button Color',
      default: '#4a4e69'
    }
  ]
};

interface ModernBannerProps {
  section: Section;
  isEditing?: boolean;
  isSelected?: boolean;
  onUpdateSection?: (section: Section) => void;
  className?: string;
}

interface ModernBannerComponentProps extends FC<ModernBannerProps> {
  schema?: SectionSchema;
}

export const ModernBannerComponent: FC<ModernBannerProps> & { schema?: SectionSchema } = ({ 
  section, 
  isEditing, 
  isSelected, 
  onUpdateSection,  
  className
}) => {
  console.log('Modern Banner Component Rendering', { section, isEditing, isSelected });

  const { 
    headline = 'Elevate Your Business', 
    subheadline = 'Discover innovative solutions that transform your workflow',
    ctaButtonUrl = '#'
  } = (section.content || {}) as any;

  const { 
    layout = 'centered', 
    backgroundColor = '#1a1a2e', 
    textColor = '#ffffff',
    ctaButtonColor = '#4a4e69'
  } = section.settings || {};

  const bannerClasses = clsx(
    'w-full py-16 px-4 sm:px-6 lg:px-8',
    className,
    {
      'text-center': layout === 'centered',
      'grid grid-cols-1 md:grid-cols-2 gap-8': layout === 'split'
    }
  );

  function renderCenteredLayout() {
    return (
      <div 
        className={clsx(
          layout === 'centered' ? 'text-center' : 'flex items-center',
        )}
        style={{ 
          backgroundColor, 
          color: textColor 
        }}
      >
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold mb-4">{headline}</h1>
          <p className="text-xl mb-6">{subheadline}</p>
          <a 
            href={ctaButtonUrl} 
            className="inline-block px-6 py-3 rounded-lg text-white font-semibold transition-colors duration-300"
            style={{ backgroundColor: ctaButtonColor }}
          >
            Get Started
          </a>
        </div>
      </div>
    );
  }

  function renderSplitLayout() {
    return (
      <div 
        className={clsx(
          layout === 'centered' ? 'text-center' : 'flex items-center',
        )}
        style={{ 
          backgroundColor, 
          color: textColor 
        }}
      >
        <div className="container mx-auto flex items-center">
          <div className="w-full md:w-1/2 pr-8">
            <h1 className="text-4xl font-bold mb-4">{headline}</h1>
            <p className="text-xl mb-6">{subheadline}</p>
            <a 
              href={ctaButtonUrl} 
              className="inline-block px-6 py-3 rounded-lg text-white font-semibold transition-colors duration-300"
              style={{ backgroundColor: ctaButtonColor }}
            >
              Get Started
            </a>
          </div>
          <div className="hidden md:block w-1/2">
            {/* Optional: Add an image or illustration here */}
            <div className="bg-gray-200 h-64 rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <SectionWrapper 
      section={section} 
      isEditing={isEditing} 
      isSelected={isSelected} 
      className={className}
    >
      {layout === 'centered' ? renderCenteredLayout() : renderSplitLayout()}
    </SectionWrapper>
  );
};

ModernBannerComponent.displayName = 'ModernBannerComponent';
ModernBannerComponent.schema = modernBannerSchema;
