// src/sections/banner/banner-component.tsx
import React from 'react';
import { Section, SectionType, SectionSchema } from '@/app/builder/builder';
import clsx from 'clsx';
import SectionWrapper from '@/app/builder/components/SectionWrapper';

export const bannerSchema: SectionSchema = {
  name: 'Banner',
  type: SectionType.Banner,
  schema: [
    {
      id: 'title',
      type: 'text',
      label: 'Title',
      default: 'Your Banner Title'
    },
    {
      id: 'description',
      type: 'textarea',
      label: 'Description',
      default: 'Add your banner description here'
    }
  ],
  settings: [
    {
      id: 'textAlignment',
      type: 'select',
      label: 'Text Alignment',
      options: [
        { value: 'left', label: 'Left' },
        { value: 'center', label: 'Center' },
        { value: 'right', label: 'Right' }
      ],
      default: 'center'
    },
    {
      id: 'backgroundColor',
      type: 'color',
      label: 'Background Color',
      default: '#f0f0f0'
    },
    {
      id: 'textColor',
      type: 'color',
      label: 'Text Color',
      default: '#000000'
    },
    {
      id: 'buttonText',
      type: 'text',
      label: 'Button Text',
      default: 'Learn More'
    },
    {
      id: 'buttonLink',
      type: 'text',
      label: 'Button Link',
      default: '#'
    }
  ]
};

type SectionComponentProps = {
  section: Section;
  isEditing?: boolean;
  isSelected?: boolean;
  onUpdateSection?: (updates: Partial<Section>) => void;
  className?: string;
};

const BannerComponent: React.FC<SectionComponentProps> & { schema?: SectionSchema } = ({ 
  section, 
  isEditing, 
  isSelected, 
  onUpdateSection,  
  className
}) => {
  const resolvedSettings = {
    title: section.settings?.title || 'Your Banner Title',
    description: section.settings?.description || 'Add your banner description here',
    textAlignment: section.settings?.textAlignment || 'center',
    backgroundColor: section.settings?.backgroundColor || '#f0f0f0',
    textColor: section.settings?.textColor || '#000000',
    buttonText: section.settings?.buttonText || 'Learn More',
    buttonLink: section.settings?.buttonLink || '#',
    buttonStyle: section.settings?.buttonStyle || 'primary'
  };

  return (
    <SectionWrapper 
      section={section} 
      isEditing={isEditing} 
      isSelected={isSelected} 
      className={className}
    >
      <div
        className={clsx(
          'p-8 rounded-lg shadow-md',
          className,
          {
            'text-left': resolvedSettings.textAlignment === 'left',
            'text-center': resolvedSettings.textAlignment === 'center',
            'text-right': resolvedSettings.textAlignment === 'right'
          }
        )}
        style={{ 
          backgroundColor: resolvedSettings.backgroundColor,
          color: resolvedSettings.textColor 
        }}
      >
        <div className="max-w-4xl mx-auto text-center">
          {resolvedSettings.title && <h1 className="text-3xl font-bold mb-4" style={{ color: resolvedSettings.textColor }}>{resolvedSettings.title}</h1>}
          {resolvedSettings.description && <p className="text-lg" style={{ color: resolvedSettings.textColor }}>{resolvedSettings.description}</p>}
          {resolvedSettings.buttonText && (
            <a
              href={resolvedSettings.buttonLink}
              className={`inline-block mt-4 px-6 py-2 rounded ${
                resolvedSettings.buttonStyle === 'primary' 
                  ? 'bg-blue-500 text-white' 
                  : resolvedSettings.buttonStyle === 'secondary'
                  ? 'bg-gray-500 text-white'
                  : 'border border-blue-500 text-blue-500'
              }`}
            >
              {resolvedSettings.buttonText}
            </a>
          )}
        </div>
      </div>
    </SectionWrapper>
  );
};

BannerComponent.schema = bannerSchema;
export { BannerComponent };
