// src/sections/banner/index.ts
import { BannerComponent, bannerSchema } from './banner-component';
import { ModernBannerComponent, modernBannerSchema } from './modernBanner-component';

export { 
  BannerComponent, 
  bannerSchema,
  ModernBannerComponent,
  modernBannerSchema
};

// Optionally, you can export an object containing special sections if needed
// For this setup, it's not necessary as each component is treated separately
