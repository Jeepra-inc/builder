import { ReactNode, ComponentType } from 'react';

export interface BaseBlockSettings {
  id: string;
  type: string;
}

export interface BlockComponentProps<T extends BaseBlockSettings> {
  block: T;
  isEditing?: boolean;
  onUpdate?: (updatedBlock: T) => void;
  onMoveUp?: () => void;
  onMoveDown?: () => void;
  onDelete?: () => void;
  settingsComponent?: ReactNode;
}

export interface BlockSettings extends BaseBlockSettings {
  // Add any common block settings here
  label?: string;
  description?: string;
}

export interface HeadingBlockSettings extends BlockSettings {
  content: string;
  level: number;
  alignment?: 'left' | 'center' | 'right';
}

export interface ParagraphBlockSettings extends BlockSettings {
  content: string;
  alignment?: 'left' | 'center' | 'right';
}

export interface ImageBlockSettings extends BlockSettings {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  caption?: string;
}

export interface BlockRegistryItem {
  component: ComponentType<BlockComponentProps<any>> & {
    Settings?: ComponentType<{
      block: BaseBlockSettings;
      onUpdate: (updatedBlock: BaseBlockSettings) => void;
    }>;
  };
  defaultSettings: () => BaseBlockSettings;
}

export type BlockSettingsType =
  | ImageBlockSettings
  | HeadingBlockSettings
  | ParagraphBlockSettings;
