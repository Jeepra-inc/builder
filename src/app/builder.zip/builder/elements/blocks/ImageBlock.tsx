import React from 'react';
import Image from 'next/image';
import type { ImageBlockSettings } from '@/app/builder/elements/blocks/types'; // Use type-only import
import { BlockComponentProps } from '@/app/builder/elements/blocks/types';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { withBlockActions } from './withBlockActions';

export const ImageBlockContent: React.FC<BlockComponentProps<ImageBlockSettings>> = ({
  block,
}) => {
  return (
    <div className="relative flex-grow">
      <Image
        src={block.src}
        alt={block.alt}
        width={block.width || 300}
        height={block.height || 200}
        className="w-full h-auto object-cover"
      />
      {block.caption && <p className="text-center mt-2">{block.caption}</p>}
    </div>
  );
};

interface ImageBlockSettingsComponentProps {
  block: ImageBlockSettings;
  onUpdate: (updatedBlock: ImageBlockSettings) => void;
}

// Rename component to avoid naming conflict
export const ImageBlockSettingsPanel: React.FC<ImageBlockSettingsComponentProps> = ({
  block,
  onUpdate,
}) => {
  const [localBlock, setLocalBlock] = React.useState(block);

  const handleChange = (field: keyof ImageBlockSettings, value: string) => {
    const updated = { ...localBlock, [field]: value };
    setLocalBlock(updated);
    onUpdate(updated);
  };

  return (
    <div className="space-y-4">
      <div>
        <Label>Image URL</Label>
        <Input
          value={localBlock.src}
          onChange={(e) => handleChange('src', e.target.value)}
          placeholder="Enter image URL"
        />
      </div>
      <div>
        <Label>Alt Text</Label>
        <Input
          value={localBlock.alt}
          onChange={(e) => handleChange('alt', e.target.value)}
          placeholder="Enter alt text"
        />
      </div>
      <div>
        <Label>Caption</Label>
        <Input
          value={localBlock.caption || ''}
          onChange={(e) => handleChange('caption', e.target.value)}
          placeholder="Enter image caption"
        />
      </div>
    </div>
  );
};

export const ImageBlock = withBlockActions(ImageBlockContent) as React.FC<
  BlockComponentProps<ImageBlockSettings>
> & {
  displayName: string;
  Settings: typeof ImageBlockSettingsPanel;
};
ImageBlock.displayName = 'ImageBlock';
ImageBlock.Settings = ImageBlockSettingsPanel;

export default ImageBlock;
