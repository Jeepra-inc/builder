import React, { useState } from 'react';
import type { HeadingBlockSettings } from '@/app/builder/elements/blocks/types'; // Use type-only import
import { BlockComponentProps } from '@/app/builder/elements/blocks/types';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { withBlockActions } from './withBlockActions';

export const HeadingBlockContent: React.FC<BlockComponentProps<HeadingBlockSettings>> = ({
  block,
}) => {
  return React.createElement(
    `h${block.level || 2}`, 
    { 
      className: `
        ${
          {
            left: 'text-left',
            center: 'text-center',
            right: 'text-right'
          }[block.alignment || 'left']
        }
      ` 
    }, 
    block.content
  );
};

interface HeadingBlockSettingsComponentProps {
  block: HeadingBlockSettings;
  onUpdate: (updatedBlock: HeadingBlockSettings) => void;
}

// Rename this component to avoid conflict with the interface name
export const HeadingBlockSettingsPanel: React.FC<HeadingBlockSettingsComponentProps> = ({
  block,
  onUpdate
}) => {
  const [localBlock, setLocalBlock] = useState(block);

  const handleChange = (field: keyof HeadingBlockSettings, value: string) => {
    const updated = { ...localBlock, [field]: value };
    setLocalBlock(updated);
    onUpdate(updated);
  };

  return (
    <div className="space-y-4">
      <div>
        <Label>Heading Content</Label>
        <Input 
          value={localBlock.content}
          onChange={(e) => handleChange('content', e.target.value)}
          placeholder="Enter heading text"
        />
      </div>
      <div>
        <Label>Heading Level</Label>
        <Select 
          value={`${localBlock.level || 2}`} 
          onValueChange={(value) => handleChange('level', value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select heading level" />
          </SelectTrigger>
          <SelectContent>
            {[1, 2, 3, 4, 5, 6].map((level) => (
              <SelectItem key={level} value={`${level}`}>
                H{level}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label>Alignment</Label>
        <Select 
          value={localBlock.alignment || 'left'} 
          onValueChange={(value) => handleChange('alignment', value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select alignment" />
          </SelectTrigger>
          <SelectContent>
            {['left', 'center', 'right'].map((alignment) => (
              <SelectItem key={alignment} value={alignment}>
                {alignment.charAt(0).toUpperCase() + alignment.slice(1)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export const HeadingBlock = withBlockActions(HeadingBlockContent);
HeadingBlock.displayName = 'HeadingBlock';
HeadingBlock.Settings = HeadingBlockSettingsPanel;

export default HeadingBlock;
