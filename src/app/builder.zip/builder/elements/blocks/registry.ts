import ImageBlock, { ImageBlockSettingsPanel } from './ImageBlock';
import HeadingBlock, { HeadingBlockSettingsPanel }  from './HeadingBlock';
import ParagraphBlock, { ParagraphBlockConfigPanel } from './ParagraphBlock';
import {BlockSettings, ImageBlockSettings}  from './types';
import ComponentType  from 'react';
import {Heading, Image, AlignLeft}  from 'lucide-react';

export interface BlockRegistryItem {
  component: React.FC<any> & { Settings?: React.FC<any> };
  defaultSettings: () => BlockSettings;
  icon: React.FC<{ className?: string }>;
}

export const BlockRegistry: Record<string, BlockRegistryItem> = {
  image: {
    component: ImageBlock,
    defaultSettings: () => ({
      id: '',
      type: 'image',
      src: '/placeholder-image.png',
      alt: 'Default Image',
      width: 300,
      height: 200,
    } as ImageBlockSettings),
    icon: Image,
    Settings: ImageBlockSettingsPanel
  },
  heading: {
    component: HeadingBlock,
    defaultSettings: () => ({
      id: '',
      type: 'heading',
      content: 'New Heading',
      level: 2,
      alignment: 'center'
    }),
    icon: Heading,
    Settings: HeadingBlockSettingsPanel
  },
  paragraph: {
    component: ParagraphBlock,
    defaultSettings: () => ({
      id: '',
      type: 'paragraph',
      content: 'Enter your text here...',
      alignment: 'left'
    }),
    icon: AlignLeft,
    Settings: ParagraphBlockConfigPanel
  }
};

export const createDefaultBlock = (
  blockType: keyof typeof BlockRegistry, 
  customDefaults?: Partial<BlockSettings>
): BlockSettings => {
  const blockSettings = BlockRegistry[blockType].defaultSettings();
  return {
    ...blockSettings,
    ...customDefaults,
    id: crypto.randomUUID()
  };
};
