import React from 'react';
import type { ParagraphBlockSettings as ParagraphSettingsType } from '@/app/builder/elements/blocks/types';
import { BlockComponentProps } from '@/app/builder/elements/blocks/types';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { withBlockActions } from './withBlockActions';

export const ParagraphBlockContent: React.FC<BlockComponentProps<ParagraphSettingsType>> = ({
  block,
}) => {
  return (
    <p
      className={`
        ${
          {
            left: 'text-left',
            center: 'text-center',
            right: 'text-right'
          }[block.alignment || 'left']
        }
      `}
    >
      {block.content}
    </p>
  );
};

export const ParagraphBlockConfigPanel: React.FC<{
  block: ParagraphSettingsType;
  onUpdate: (updatedBlock: ParagraphSettingsType) => void;
}> = ({ block, onUpdate }) => {
  const [localBlock, setLocalBlock] = React.useState(block);

  const handleChange = (field: keyof ParagraphSettingsType, value: string) => {
    const updated = { ...localBlock, [field]: value };
    setLocalBlock(updated);
    onUpdate(updated);
  };

  return (
    <div className="space-y-4">
      <div>
        <Label>Paragraph Content</Label>
        <Textarea
          value={localBlock.content}
          onChange={(e) => handleChange('content', e.target.value)}
          placeholder="Enter paragraph text"
          rows={4}
        />
      </div>
      <div>
        <Label>Alignment</Label>
        <Select
          value={localBlock.alignment || 'left'}
          onValueChange={(value) => handleChange('alignment', value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select alignment" />
          </SelectTrigger>
          <SelectContent>
            {['left', 'center', 'right'].map((alignment) => (
              <SelectItem key={alignment} value={alignment}>
                {alignment.charAt(0).toUpperCase() + alignment.slice(1)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export const ParagraphBlock = withBlockActions(ParagraphBlockContent);
ParagraphBlock.displayName = 'ParagraphBlock';
ParagraphBlock.Settings = ParagraphBlockConfigPanel;

export default ParagraphBlock;
