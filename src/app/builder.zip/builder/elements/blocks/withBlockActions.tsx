import React, { ComponentType, useState, useRef, useEffect } from 'react';
import BlockActions from './BlockActions';
import { BlockComponentProps, BaseBlockSettings } from '@/app/builder/elements/blocks/types';
import { BlockRegistry } from './registry';
import { createPortal } from 'react-dom';
import { Edit } from 'lucide-react'; // Corrected import

// Define a type that extends a component with an optional Settings property.
type WithSettingsComponent<T extends BlockComponentProps<any>> = React.FC<T> & {
  Settings?: React.FC<{
    block: T['block'];
    onUpdate: (updatedBlock: T['block']) => void;
  }>;
};

// Global debug overlay component
const BlockSettingsDebugOverlay: React.FC<{ block: any; isVisible: boolean; setShowDebugOverlay: (show: boolean) => void }> = ({ block, isVisible, setShowDebugOverlay }) => {
  if (!isVisible) return null;

  return createPortal(
    <div 
      style={{
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        backgroundColor: 'white',
        padding: '20px',
        borderRadius: '8px',
        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
        zIndex: 1000,
        maxWidth: '400px',
        wordBreak: 'break-all'
      }}
    >
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold">Block Settings Debug</h2>
        <button 
          onClick={() => setShowDebugOverlay(false)}
          className="text-red-300 hover:text-red-500"
        >
          ✕
        </button>
      </div>
      <pre>{JSON.stringify(block, null, 2)}</pre>
    </div>,
    document.body
  );
};

export function withBlockActions<T extends BlockComponentProps<any>>(
  WrappedComponent: ComponentType<T>
): WithSettingsComponent<T> {
  const BlockActionWrapper: React.FC<T> = (props: T) => {
    const {
      block,
      onMoveUp,
      onMoveDown,
      onDelete,
      onUpdate,
      isEditing = false,
    } = props;

    const [editedBlock, setEditedBlock] = useState(block);
    const [isEditingSettings, setIsEditingSettings] = useState(false);
    const [showBlockSettingsInPanel, setShowBlockSettingsInPanel] = useState(false);
    const [showDebugOverlay, setShowDebugOverlay] = useState(false);
    const settingsRef = useRef<HTMLDivElement>(null);
    const blockActionsRef = useRef<HTMLDivElement>(null);

    const handleUpdate = (updatedBlock: typeof block) => {
      setEditedBlock(updatedBlock);
      setShowDebugOverlay(true);
      onUpdate?.(updatedBlock);
    };

    // Prevent settings from closing when clicking inside
    useEffect(() => {
      const preventClose = (event: Event) => {
        if (
          isEditingSettings && 
          settingsRef.current && 
          blockActionsRef.current
        ) {
          const isInsideSettings = settingsRef.current.contains(event.target as Node);
          const isInsideBlockActions = blockActionsRef.current.contains(event.target as Node);

          if (!isInsideSettings && !isInsideBlockActions) {
            setIsEditingSettings(false);
          }
        }
      };

      document.addEventListener('mousedown', preventClose);
      document.addEventListener('click', preventClose, true);

      return () => {
        document.removeEventListener('mousedown', preventClose);
        document.removeEventListener('click', preventClose, true);
      };
    }, [isEditingSettings]);

    // Safely attempt to fetch the Settings component from the registry
    const SettingsComponent =
      block.type && BlockRegistry[block.type as keyof typeof BlockRegistry]?.component.Settings;

    // Send block settings to parent window
    useEffect(() => {
      if (showBlockSettingsInPanel) {
        window.parent.postMessage({
          type: 'SHOW_BLOCK_SETTINGS',
          block: editedBlock
        }, '*');
      }
    }, [showBlockSettingsInPanel, editedBlock]);

    return (
      <div className="relative group" ref={blockActionsRef}>
        <div className="flex items-center justify-between">
          <div className="flex-grow">
            <WrappedComponent
              {...props}
              block={editedBlock}
              onUpdate={handleUpdate}
              isEditing={isEditing || isEditingSettings}
            />
          </div>

          <BlockActions
            onMoveUp={onMoveUp}
            onMoveDown={onMoveDown}
            onDelete={onDelete}
            editContent={
              isEditingSettings && SettingsComponent
                ? (
                  <div 
                    ref={settingsRef} 
                    onClick={(e) => e.stopPropagation()}
                    onMouseDown={(e) => e.stopPropagation()}
                  >
                    {React.createElement(SettingsComponent, {
                      block: editedBlock,
                      onUpdate: (updatedBlock: T['block']) => {
                        handleUpdate(updatedBlock);
                        // Do not automatically close settings
                      },
                    })}
                  </div>
                )
                : null
            }
            onEdit={
              isEditing || isEditingSettings
                ? undefined
                : () => {
                  setIsEditingSettings(true);
                  window.parent.postMessage({
                    type: 'SHOW_BLOCK_SETTINGS',
                    block: {
                      ...block,
                      type: block.type,
                      id: block.id
                    }
                  }, '*');
                }
            }
          />
        </div>
        <BlockSettingsDebugOverlay block={block} isVisible={showDebugOverlay} setShowDebugOverlay={setShowDebugOverlay} />
      </div>
    );
  };

  BlockActionWrapper.displayName = `withBlockActions(${
    WrappedComponent.displayName || WrappedComponent.name || 'Component'
  })`;

  // Assert the type so we can assign a Settings component outside if needed.
  return BlockActionWrapper as WithSettingsComponent<T>;
}
