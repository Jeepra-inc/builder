import React from 'react';
import { Button } from '@/components/ui/button';
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from '@/components/ui/popover';
import { ArrowUp, ArrowDown, Trash2, Edit3, Settings } from 'lucide-react';

export interface BlockActionsProps {
  onMoveUp?: () => void;
  onMoveDown?: () => void;
  onDelete?: () => void;
  onEdit?: () => void;
  isFirstBlock?: boolean;
  isLastBlock?: boolean;
  editContent?: React.ReactNode;
}

export const BlockActions: React.FC<BlockActionsProps> = ({
  onMoveUp,
  onMoveDown,
  onDelete,
  onEdit,
  isFirstBlock = false,
  isLastBlock = false,
  editContent
}) => {
  return (
    <div className="flex items-center space-x-1">
      {onMoveUp && !isFirstBlock && (
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-6 w-6 text-gray-500 hover:text-blue-600"
          onClick={onMoveUp}
        >
          <ArrowUp className="h-4 w-4" />
        </Button>
      )}
      
      {onMoveDown && !isLastBlock && (
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-6 w-6 text-gray-500 hover:text-blue-600"
          onClick={onMoveDown}
        >
          <ArrowDown className="h-4 w-4" />
        </Button>
      )}
      
      {onDelete && (
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-6 w-6 text-gray-500 hover:text-red-600"
          onClick={onDelete}
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      )}
      
      {(onEdit || editContent) && (
        <Popover>
          <PopoverTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon"
              className="h-6 w-6 text-gray-500 hover:text-blue-600"
              onClick={onEdit}
            >
              <Edit3 className="h-4 w-4" />
            </Button>
          </PopoverTrigger>
          {editContent && (
            <PopoverContent className="w-80">
              {editContent}
            </PopoverContent>
          )}
        </Popover>
      )}
    </div>
  );
};

export default BlockActions;
