export enum SectionType {
  Text = 'text',
  Banner = 'banner',
  ModernBanner = 'modernBanner',
  Hero = 'hero1',
  Accordion = 'accordion',
  Multicolumn = 'multicolumn',
  Card = 'card'
}

export interface Section {
  id: string;
  type: SectionType;
  content?: {
    [key: string]: any;
    headline?: string;
    subheadline?: string;
    ctaButtonUrl?: string;
  };
  settings: {
    [key: string]: any;
    items?: {
      id: string;
      title: string;
      content: string;
      blocks?: {
        id: string;
        type: string;
      }[];
    }[];
    title?: string;
    subtitle?: string;
    image?: string;
  };
  blocks?: Block[];
  props?: Record<string, any>; 
  isVisible?: boolean;
}

export interface Block {
  id: string;
  type: string;
  settings: Record<string, any>;
}

export interface SectionSchema {
  name: string;
  type: string;
  category?: string;
  schema: SettingField[];
  blocks?: BlockSchema[];
  thumbnail?: string;
  settings?: Record<string, any>;
}

export interface BlockSchema {
  type: string;
  name: string;
  settings: SettingField[];
}

export interface SettingField {
  type: 
    | 'text'
    | 'textarea'
    | 'number'
    | 'email'
    | 'url'
    | 'password'
    | 'color'
    | 'image'
    | 'file'
    | 'range'
    | 'select'
    | 'multiselect'
    | 'checkbox'
    | 'radio'
    | 'switch'
    | 'date'
    | 'time'
    | 'datetime';
  
  id: string;
  label: string;
  placeholder?: string;
  description?: string;
  subtitle?: string;
  image?: string;
  default?: any;
  required?: boolean;
  disabled?: boolean;
  readonly?: boolean;
  min?: number;
  max?: number;
  step?: number;
  pattern?: string;
  options?: Array<{ 
    label: string; 
    value: string; 
    disabled?: boolean 
  }>;
  validation?: {
    required?: boolean;
    minLength?: number;
    maxLength?: number;
    pattern?: string;
  };
  of?: any[]; 
}

export interface SectionComponentProps {
  section: Section;
  isEditing?: boolean;
  isSelected?: boolean;
  className?: string;
  'data-section-type'?: SectionType;
  onUpdateSection?: (updates: Partial<Section>) => void;
  onSelectAccordionItem?: (itemId: string | null) => void;
  schema?: SectionSchema;
}

export interface Theme {
  id: string;
  name: string;
  sections: {
    [key: string]: {
      name: string;
      settings?: Record<string, any> | any[]; 
    };
  };
}
