// IframeContent.tsx
'use client';

import React, {
  useRef,
  useEffect,
  useCallback,
  useReducer,
  useState,
} from 'react';
import { TooltipProvider } from '@/components/ui/tooltip';

import {
  sectionsReducer as importedSectionsReducer,
  initialSectionState,
  SectionState,
  Section,
  SectionAction,
} from '../components/sectionReducer';
import { SectionType } from '@/app/builder/builder';
import { AddSectionModal } from '../components/AddSectionModal';
import { SectionControls } from '../components/SectionControls';

import { allComponents } from '@/app/builder/elements/sections'; 

export default function IframeContent() {
  // ----------------- State + Reducer -----------------
  const [state, dispatch] = useReducer(localSectionsReducer, initialSectionState);
  const { sections } = state;
  
  // Restore previously removed state variables
  const [selectedSectionId, setSelectedSectionId] = useState<string | null>(null);
  const [hoveredSection, setHoveredSection] = useState<string | null>(null);
  const [lastMovedSection, setLastMovedSection] = useState<string | null>(null);
  const [activeInsertIndex, setActiveInsertIndex] = useState<number | null>(null);

  // Refs
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const sectionRefs = useRef<{ [key: string]: React.RefObject<HTMLDivElement> }>({});
  const contentRef = useRef<HTMLIFrameElement>(null);

  // Ensure sections are always available
  const [localSections, setLocalSections] = useState<Section[]>(sections);

  // Helper function to generate unique IDs
  const generateUniqueId = () => {
    return `section_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  };

  // Helper functions
  const updateSection = useCallback((sectionId: string, updates: Partial<Section>) => {
    const updatedSections = localSections.map(section => 
      section.id === sectionId 
        ? { ...section, ...updates } 
        : section
    );
    
    setLocalSections(updatedSections);
    dispatch({
      type: 'UPDATE_SECTION',
      sectionId,
      updates
    });
  }, [localSections]);

  const duplicateSection = useCallback((sectionId: string) => {
    const sectionToDuplicate = localSections.find(s => s.id === sectionId);
    if (!sectionToDuplicate) return;

    const sectionIndex = localSections.findIndex(s => s.id === sectionId);
    const newSection: Section = {
      ...sectionToDuplicate,
      id: generateUniqueId(), // Ensure a new unique ID
    };

    const updatedSections = [...localSections];
    updatedSections.splice(sectionIndex + 1, 0, newSection);

    setLocalSections(updatedSections);
    dispatch({
      type: 'ADD_SECTION',
      payload: newSection,
      index: sectionIndex + 1
    });
  }, [localSections]);

  const deleteSection = useCallback((sectionId: string) => {
    const updatedSections = localSections.filter(section => section.id !== sectionId);
    
    setLocalSections(updatedSections);
    dispatch({
      type: 'DELETE_SECTION',
      sectionId
    });
  }, [localSections]);

  const moveSectionVertically = useCallback((sectionId: string, direction: 'up' | 'down') => {
    const currentIndex = localSections.findIndex(s => s.id === sectionId);
    if (currentIndex === -1) return;

    const newIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    if (newIndex < 0 || newIndex >= localSections.length) return;

    const updatedSections = [...localSections];
    const [removed] = updatedSections.splice(currentIndex, 1);
    updatedSections.splice(newIndex, 0, removed);

    setLocalSections(updatedSections);
    dispatch({
      type: 'REORDER_SECTIONS',
      payload: updatedSections
    });
  }, [localSections]);

  // Sync local sections with state
  useEffect(() => {
    console.log('Syncing local sections with state:', {
      stateSections: sections,
      localSections
    });
    
    if (sections.length > 0) {
      setLocalSections(sections);
    }
  }, [sections]);
  
  // Log sections on every render
  useEffect(() => {
    console.log('Sections state updated:', {
      sections: localSections,
      sectionCount: localSections.length,
      sectionDetails: localSections.map(s => ({
        id: s.id,
        type: s.type,
        isVisible: s.settings?.isVisible,
        settings: s.settings
      }))
    });
  }, [localSections]);

  // Helper function to get section ref
  const getSectionRef = useCallback((sectionId: string) => {
    if (!sectionRefs.current[sectionId]) {
      sectionRefs.current[sectionId] = React.createRef<HTMLDivElement>();
    }
    return sectionRefs.current[sectionId];
  }, []);

  const handleMessage = useCallback(
    (event: MessageEvent) => {
      if (!event.data || !event.data.type) {
        console.warn('Invalid message received');
        return;
      }

      switch (event.data.type) {
        case 'TOGGLE_SECTION_VISIBILITY': {
          const { sectionId, isVisible } = event.data;
          
          if (!sectionId) {
            console.error('Invalid sectionId in visibility toggle');
            return;
          }

          // Prevent duplicate dispatches
          const existingSection = localSections.find(s => s.id === sectionId);
          
          // Only dispatch if the visibility is actually changing
          if (!existingSection || existingSection.isVisible !== isVisible) {
            // Update both local and global state
            setLocalSections(prevSections => 
              prevSections.map(section => 
                section.id === sectionId
                  ? { 
                      ...section, 
                      isVisible: isVisible ?? section.isVisible,
                      settings: {
                        ...section.settings,
                        isVisible: isVisible ?? section.settings?.isVisible ?? true
                      }
                    }
                  : section
              )
            );

            // Dispatch action to update global state
            dispatch({
              type: 'TOGGLE_SECTION_VISIBILITY',
              sectionId,
              isVisible
            });
          }
          break;
        }

        case 'UPDATE_SECTION': {
          dispatch({
            type: 'UPDATE_SECTION',
            sectionId: event.data.sectionId,
            updates: event.data.updates.settings ?? {},
          });
          break;
        }

        case 'SECTIONS_UPDATED': {
          dispatch({ type: 'SET_SECTIONS', payload: event.data.sections });
          break;
        }

        case 'DELETE_SECTION': {
          dispatch({
            type: 'DELETE_SECTION', 
            sectionId: event.data.sectionId
          });
          break;
        }

        case 'ADD_SECTION': {
          dispatch({
            type: 'ADD_SECTION',
            payload: event.data.section,
            index: event.data.index,
          });

          // If scrollToSection flag is true, scroll to the newly added section
          if (event.data.scrollToSection) {
            const newSectionId = event.data.section.id;
            
            // Use setTimeout to ensure the section is rendered before scrolling
            setTimeout(() => {
              const sectionRef = sectionRefs.current[newSectionId];
              sectionRef?.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 100);
          }
          break;
        }

        case 'SCROLL_TO_SECTION': {
          const sectionId = event.data.sectionId;
          const sectionRef = sectionRefs.current[sectionId];
          sectionRef?.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
          break;
        }

        case 'REORDER_SECTIONS': {
          dispatch({ type: 'REORDER_SECTIONS', payload: event.data.sections });
          if (event.data.scrollToSectionId) {
            setHoveredSection(event.data.scrollToSectionId);
            const sectionRef = sectionRefs.current[event.data.scrollToSectionId];
            sectionRef?.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setTimeout(() => setHoveredSection(null), 2000);
          }
          break;
        }

        case 'HOVER_SECTION': {
          const id = event.data.sectionId;
          setHoveredSection(id);
          const sectionRef = sectionRefs.current[id];
          sectionRef?.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
          setTimeout(() => setHoveredSection(null), 2000);
          break;
        }

        case 'UNDO': {
          dispatch({ type: 'UNDO' });
          break;
        }

        case 'REDO': {
          dispatch({ type: 'REDO' });
          break;
        }

        case 'DUPLICATE_LAYER': {
          console.log('Duplicate Layer Event:', event.data);
          
          const newSection = {
            ...event.data.layer,
            id: `section_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          };
          
          const insertIndex = event.data.currentIndex !== undefined 
            ? event.data.currentIndex + 1 
            : sections.length;
          
          console.log('Insert Index:', insertIndex);
          
          dispatch({
            type: 'ADD_SECTION', 
            payload: newSection,
            index: insertIndex
          });
          break;
        }
        
        case 'DELETE_LAYER': {
          dispatch({
            type: 'DELETE_SECTION', 
            sectionId: event.data.layerId
          });
          break;
        }

        default:
          console.warn(`Unhandled message type: ${event.data.type}`);
      }
    },
    [localSections, dispatch]
  );

  useEffect(() => {
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [handleMessage]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (!selectedSectionId) return;

      if (event.key === 'ArrowUp') {
        event.preventDefault();
        moveSectionVertically(selectedSectionId, 'up');
      } else if (event.key === 'ArrowDown') {
        event.preventDefault();
        moveSectionVertically(selectedSectionId, 'down');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedSectionId, moveSectionVertically]);

  // ----------------- Lifecycle: Ensure Refs + Notify Parent -----------------
  useEffect(() => {
    sections.forEach((section) => {
      if (!sectionRefs.current[section.id]) {
        sectionRefs.current[section.id] = React.createRef<HTMLDivElement>();
      }
    });
  }, [sections]);

  useEffect(() => {
    // Notify parent about updates
    if (window.parent) {
      window.parent.postMessage({ type: 'SECTIONS_UPDATED', sections }, '*');
    }
  }, [sections]);

  // Helper function to handle section click
  const handleSectionClick = useCallback((sectionId: string) => {
    setSelectedSectionId(sectionId);
    window.parent.postMessage(
      {
        type: 'SECTION_SELECTED',
        sectionId,
        action: 'OPEN_SETTINGS',
      },
      '*'
    );
  }, []);

  // Helper function to handle undo
  const handleUndo = () => dispatch({ type: 'UNDO' });

  // Helper function to handle redo
  const handleRedo = () => dispatch({ type: 'REDO' });

  // Helper function to handle add section
  const handleAddSection = useCallback((sectionType: string, index?: number) => {
    const newSection = {
      id: generateUniqueId(),
      type: sectionType as SectionType,
      content: {},
      settings: {}
    };

    dispatch({
      type: 'ADD_SECTION',
      payload: newSection,
      index,
    });
    setActiveInsertIndex(null);

    setTimeout(() => {
      if (scrollAreaRef.current) {
        scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
      }
    }, 100);
  }, []);

  // ----------------- RENDER -----------------
  return (
    <TooltipProvider>
      <div className="relative w-full h-full" ref={scrollAreaRef}>
        {localSections.map((section, index) => {
          // Explicitly determine visibility
          const isVisible = section.isVisible !== false && section.settings?.isVisible !== false;

          console.log(`Rendering section ${section.id}:`, {
            type: section.type,
            isVisible,
            explicitIsVisible: section.isVisible,
            settingsVisible: section.settings?.isVisible
          });

          // Skip rendering if not visible
          if (!isVisible) {
            console.log(`Skipping rendering of section ${section.id}`);
            return null;
          }

          const SectionComponent = allComponents[section.type];

          if (!SectionComponent) {
            console.error(`No component found for section type: ${section.type}`);
            return null;
          }

          return (
            <div
              key={section.id}
              className="relative group hover:outline-8"
              onMouseEnter={() => setHoveredSection(section.id)}
              onMouseLeave={() => setHoveredSection(null)}
            >
              {/* Plus Button BEFORE Section */}
              {hoveredSection === section.id && (
                <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 z-10">
                  <AddSectionModal
                    open={activeInsertIndex === index}
                    onOpenChange={(open) => setActiveInsertIndex(open ? index : null)}
                    onAddSection={(type) => handleAddSection(type, index)}
                  />
                </div>
              )}

              {/* Render section controls and content */}
              <div
                ref={getSectionRef(section.id)}
                onClick={() => handleSectionClick(section.id)}
              >
                {hoveredSection === section.id && (
                  <SectionControls
                    sectionId={section.id}
                    index={index}
                    totalSections={localSections.length}
                    onMoveUp={() => moveSectionVertically(section.id, 'up')}
                    onMoveDown={() => moveSectionVertically(section.id, 'down')}
                    onDuplicate={() => duplicateSection(section.id)}
                    onDelete={() => deleteSection(section.id)}
                    onToggleVisibility={() => {
                      // Explicitly toggle visibility
                      const newVisibility = section.isVisible !== false ? false : true;
                      dispatch({
                        type: 'TOGGLE_SECTION_VISIBILITY',
                        sectionId: section.id,
                        isVisible: newVisibility
                      });
                    }}
                    isVisible={isVisible}
                  />
                )}
                <SectionComponent
                  section={section}
                  isEditing={true}
                  isSelected={selectedSectionId === section.id}
                  onUpdateSection={(updates: Partial<Section>) => {
                    updateSection(section.id, updates);
                  }}
                />
              </div>

              {/* Plus Button AFTER Section */}
              {hoveredSection === section.id && (
                <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 z-10">
                  <AddSectionModal
                    open={activeInsertIndex === index + 1}
                    onOpenChange={(open) => setActiveInsertIndex(open ? index + 1 : null)}
                    onAddSection={(type) => handleAddSection(type, index + 1)}
                  />
                </div>
              )}
            </div>
          );
        })}
        
        {localSections.length === 0 && (
          <div className="flex justify-center">
            <AddSectionModal
              open={activeInsertIndex === 0}
              onOpenChange={(open) => setActiveInsertIndex(open ? 0 : null)}
              onAddSection={(type) => handleAddSection(type, 0)}
            />
          </div>
        )}
        
        <div className="fixed bottom-4 right-4 z-50">
          <AddSectionModal onAddSection={handleAddSection} />
        </div>
      </div>
    </TooltipProvider>
  );
}

function localSectionsReducer(state: SectionState, action: SectionAction): SectionState {
  console.log('Local Reducer Action:', action.type, action);

  switch (action.type) {
    case 'TOGGLE_SECTION_VISIBILITY':
      return {
        ...state,
        sections: state.sections.map(section => 
          section.id === action.sectionId 
            ? { 
                ...section, 
                isVisible: action.isVisible,
                settings: {
                  ...section.settings,
                  isVisible: action.isVisible
                }
              } 
            : section
        ),
        history: [
          ...state.history.slice(0, state.historyIndex + 1),
          state.sections
        ],
        historyIndex: state.historyIndex + 1
      };

    // Delegate other actions to the imported reducer
    default:
      return importedSectionsReducer(state, action);
  }
}
